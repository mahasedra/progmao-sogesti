<template>
  <v-card class="spacing-playground ma-5">
    <v-data-table :options="{ openLink }" :headers="headers" :items="gestionSecurite" :search="search"
      class="elevation-4" :loading="loading" :mobile-breakpoint="0" loading-text="Chargement...Veuillez patienter">
      <template v-slot:top>
        <v-toolbar flat>
          <v-toolbar-title>Liste</v-toolbar-title>
          <v-divider class="mx-4" inset vertical />
          <v-btn class="mx-2" fab dark small color="red" :loading="loading2" :disabled="loading2" @click="exportPDF()">
            <v-icon dark>
              mdi-file-pdf-box
            </v-icon>
          </v-btn>

          <v-btn class="mx-2" fab dark small color="green" :loading="loading1" :disabled="loading1"
            @click="exportToExcel()">
            <v-icon dark>
              mdi-cloud-upload
            </v-icon>
          </v-btn>
          <v-spacer />

          <v-dialog v-model="dialog" max-width="800px">
            <v-card>
              <v-card-title>
                <span class="headline">{{ formTitle }}</span>
              </v-card-title>

              <v-card-text>
                <v-container>
                  <v-form v-bind:disabled="loading" lazy-validation ref="dialogForm">
                    <v-row>
                      <v-col cols="12" sm="6" md="10">
                        <v-select prepend-inner-icon="mdi-apps" label="Status" :disabled="loading"
                          v-model="editedItem.status" :items="items2"></v-select>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col cols="12" sm="6" md="10">
                        <h4>Votre commentaire</h4>

                        <vue-editor v-model="editedItem.commentaireAdmin"></vue-editor>

                      </v-col>
                    </v-row>
                  </v-form>
                </v-container>
              </v-card-text>

              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn :disabled="loading" color="blue darken-1" text @click="close">Quitter</v-btn>
                <v-btn :disabled="loading" color="blue darken-1" text @click="save">Enregistrer</v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>

          <v-dialog v-model="dialogAdd" max-width="800px">
            <v-card>
              <v-card-title>
                <span class="headline">Ajouter un suivi d'armes</span>
              </v-card-title>
              <v-card-text>
                <v-container>
                  <v-form v-bind:disabled="loading" lazy-validation ref="dialogForm">
                    <v-row>
                      <v-col cols="12">
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <h4>Intitulé</h4>
                            <v-text-field outlined prepend-inner-icon="mdi-account-details-outline"
                              v-model="defaultItem.intitulePassation" label="Intitulé de la passation"
                              :rules="titleRule"></v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field outlined prepend-inner-icon="mdi-account-details-outline"
                              v-model="defaultItem.nomEtPrenomAgentEntrant" label="Agent entrant">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field outlined prepend-inner-icon="mdi-account-details-outline"
                              v-model="defaultItem.nomEtPrenomAgentSortant" label="Agent sortant">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field outlined prepend-inner-icon="mdi-account-details-outline"
                              v-model="defaultItem.vacation" label="Vacation"></v-text-field>
                          </v-col>
                        </v-row>
                        <center>
                          <h1 style="font-weight: bold">Armes</h1>
                        </center>
                        <center>
                          <h2 style="font-weight: bold">REVOLVER 9mm</h2>
                        </center>
                        <center>
                          <h3 style="font-weight: bold">RJ131910645</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field outlined prepend-inner-icon="mdi-account-details-outline"
                              v-model="defaultItem.RJ131910645etat" label="Etat"></v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.RJ131910645anomalies" label="Anomalies">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.RJ131910645observations" label="Observations">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <h3>Date de sortie</h3>
                            <input type="date" v-model="defaultItem.RJ131910645dateSortie" class="datepicker" />

                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <h3>Date de retour</h3>
                            <input type="date" v-model="defaultItem.RJ131910645dateRetour" class="datepicker" />
                          </v-col>
                        </v-row>
                        <center>
                          <h3 style="font-weight: bold">RJ120205375</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.RJ120205375etat" label="Etat"></v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.RJ120205375anomalies" label="Anomalies">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.RJ120205375observations" label="Observations">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <h3>Date de sortie</h3>
                            <input type="date" v-model="defaultItem.RJ120205375dateSortie" class="datepicker" />

                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <h3>Date de retour</h3>
                            <input type="date" v-model="defaultItem.RJ120205375dateRetour" class="datepicker" />

                          </v-col>
                        </v-row>
                        <center>
                          <h2 style="font-weight: bold">REVOLVER 6mm</h2>
                        </center>
                        <center>
                          <h3 style="font-weight: bold">RL130410466</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.RL130410466etat" label="Etat"></v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.RL130410466anomalies" label="Anomalies">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.RL130410466observations" label="Observations">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <h3>Date de sortie</h3>
                            <input type="date" v-model="defaultItem.RL130410466dateSortie" class="datepicker" />

                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <h3>Date de retour</h3>
                            <input type="date" v-model="defaultItem.RL130410466dateRetour" class="datepicker" />

                          </v-col>
                        </v-row>
                        <center>
                          <h1 style="font-weight: bold">Munitions</h1>
                        </center>
                        <center>
                          <h2 style="font-weight: bold">
                            Cartouches à blancs 9 mm
                          </h2>
                        </center>
                        <center>
                          <h3 style="font-weight: bold">TG3529AO</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOrecues" label="Nombre de munitions reçues">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOutilisees" label="Nombre de munitions utilisées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOrestantes" label="Nombre de munitions restantes">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOusees" label="Nombre de munitions usées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOdetruites" label="Nombre de munitions détruites">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOobservations" label="Observations">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <center>
                          <h3 style="font-weight: bold">TG6768AW</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWrecues" label="Nombre de munitions reçues">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWutilisees" label="Nombre de munitions utilisées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWrestantes" label="Nombre de munitions restantes">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWusees" label="Nombre de munitions usées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWdetruites" label="Nombre de munitions détruites">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWobservations" label="Observations">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <center>
                          <h2 style="font-weight: bold">
                            Cartouches à blancs 6 mm
                          </h2>
                        </center>
                        <center>
                          <h3 style="font-weight: bold">TG3529AO</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOrecues6mm" label="Nombre de munitions reçues"></v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOutilisees6mm" label="Nombre de munitions utilisées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOrestantes6mm" label="Nombre de munitions restantes">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOusees6mm" label="Nombre de munitions usées"></v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOdetruites6mm" label="Nombre de munitions détruites">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOobservations6mm" label="Observations">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <center>
                          <h3 style="font-weight: bold">TG6768AW</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWrecues6mm" label="Nombre de munitions reçues"></v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWutilisees6mm" label="Nombre de munitions utilisées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWrestantes6mm" label="Nombre de munitions restantes">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWusees6mm" label="Nombre de munitions usées"></v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWdetruites6mm" label="Nombre de munitions détruites">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWobservations6mm" label="Observations">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <center>
                          <h2 style="font-weight: bold">Fusées détonnantes</h2>
                        </center>
                        <center>
                          <h3 style="font-weight: bold">TG3529AO</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOrecuesDetonnants" label="Nombre de munitions reçues">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOutiliseesDetonnants" label="Nombre de munitions utilisées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOrestantesDetonnants" label="Nombre de munitions restantes">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOuseesDetonnants" label="Nombre de munitions usées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOdetruitesDetonnants" label="Nombre de munitions détruites">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify" v-model="
                              defaultItem.TG3529AOobservationsDetonnants
                            " label="Observations"></v-text-field>
                          </v-col>
                        </v-row>
                        <center>
                          <h3 style="font-weight: bold">TG6768AW</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWrecuesDetonnants" label="Nombre de munitions reçues">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWutiliseesDetonnants" label="Nombre de munitions utilisées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWrestantesDetonnants" label="Nombre de munitions restantes">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWuseesDetonnants" label="Nombre de munitions usées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWdetruitesDetonnants" label="Nombre de munitions détruites">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify" v-model="
                              defaultItem.TG6768AWobservationsDetonnants
                            " label="Observations"></v-text-field>
                          </v-col>
                        </v-row>
                        <center>
                          <h2 style="font-weight: bold">Fusées crépitantes</h2>
                        </center>
                        <center>
                          <h3 style="font-weight: bold">TG3529AO</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOrecuesCrepitants" label="Nombre de munitions reçues">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOutilisees" label="Nombre de munitions utilisées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOrestantesCrepitants" label="Nombre de munitions restantes">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOuseesCrepitants" label="Nombre de munitions usées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOdetruitesCrepitants" label="Nombre de munitions détruites">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify" v-model="
                              defaultItem.TG3529AOobservationsCrepitants
                            " label="Observations"></v-text-field>
                          </v-col>
                        </v-row>
                        <center>
                          <h3 style="font-weight: bold">TG6768AW</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWrecuesCrepitants" label="Nombre de munitions reçues">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWutiliseesCrepitants" label="Nombre de munitions utilisées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWrestantesCrepitants" label="Nombre de munitions restantes">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWuseesCrepitants" label="Nombre de munitions usées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWdetruitesCrepitants" label="Nombre de munitions détruites">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify" v-model="
                              defaultItem.TG6768AWobservationsCrepitants
                            " label="Observations"></v-text-field>
                          </v-col>
                        </v-row>
                        <center>
                          <h2 style="font-weight: bold">
                            Autres numitions d'effarouchement
                          </h2>
                        </center>
                        <center>
                          <h3 style="font-weight: bold">TG3529AO</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOrecuesAutres" label="Nombre de munitions reçues">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOutiliseesAutres" label="Nombre de munitions utilisées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOrestantesAutres" label="Nombre de munitions restantes">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOuseesAutres" label="Nombre de munitions usées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOdetruitesAutres" label="Nombre de munitions détruites">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG3529AOobservationsAutres" label="Observations">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <center>
                          <h3 style="font-weight: bold">TG6768AW</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWrecuesAutres" label="Nombre de munitions reçues">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWutiliseesAutres" label="Nombre de munitions utilisées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWrestantesAutres" label="Nombre de munitions restantes">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWuseesAutres" label="Nombre de munitions usées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWdetruitesAutres" label="Nombre de munitions détruites">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.TG6768AWobservationsAutres" label="Observations">
                            </v-text-field>
                          </v-col>
                        </v-row>

                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-select :items="items2" prepend-inner-icon="mdi-format-align-justify"
                              v-model="defaultItem.status" label="Statut"></v-select>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            Détails du statut
                            <vue-editor v-model="defaultItem.detailStatut" label="Détails du statut"> </vue-editor>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <h4>Votre commentaire</h4>
                            <vue-editor v-model="editedItem.commentaireAdmin"></vue-editor>
                          </v-col>
                        </v-row>

                        <v-row>
                          <v-col cols="12" sm="6" md="6">
                            <input type="file" multiple class="d-none" ref="uploader" accept="image/*"
                              @change="uploadTaskImages()" />
                            <v-btn :disabled="loading" color="primary" v-model="imagePret"
                              @click="$refs.uploader.click()">
                              <v-icon dark>
                                mdi-image-multiple
                              </v-icon> <b>Ajouter des images</b>
                            </v-btn>
                          </v-col>

                        </v-row>

                        <v-row>
                          <v-col cols="12" sm="6" md="6">
                            <input type="file" multiple class="d-none" ref="uploader1"
                              accept=".xlsx,.xls,.doc, .docx,.ppt, .pptx,.txt,.pdf" @change="uploadTaskDocuments()" />
                            <v-btn :disabled="loading" color="red" v-model="documentPret"
                              @click="$refs.uploader1.click()">
                              <v-icon dark>
                                mdi-file-arrow-up-down
                              </v-icon> <b>Ajouter des documents</b>
                            </v-btn>

                          </v-col>

                        </v-row>
                      </v-col>
                    </v-row>
                  </v-form>
                </v-container>
              </v-card-text>

              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn :disabled="loading" color="blue darken-1" text @click="closeView">Quitter</v-btn>
                <v-btn :disabled="loading" color="blue darken-1" text @click="save">Enregistrer</v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>

          <v-dialog v-model="dialogView" max-width="800px">
            <v-card>
              <v-card-title>
                <span class="headline">Détails du formulaire</span>
              </v-card-title>
              <v-card-text>
                <v-container>
                  <v-form v-bind:disabled="loading" lazy-validation ref="dialogForm">
                    <v-row>
                      <v-col cols="12">
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field outlined prepend-inner-icon="mdi-account-details-outline"
                              v-model="editedItem.userName" label="Nom et prénoms" disabled="true"></v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <h4>Intitulé</h4>
                            <v-text-field outlined prepend-inner-icon="mdi-account-details-outline"
                              v-model="editedItem.intitulePassation" label="Intitulé de la passation"
                              :rules="titleRule"></v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field outlined prepend-inner-icon="mdi-account-details-outline"
                              v-model="editedItem.nomEtPrenomAgentEntrant" label="Agent entrant">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field outlined prepend-inner-icon="mdi-account-details-outline"
                              v-model="editedItem.nomEtPrenomAgentSortant" label="Agent sortant">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field outlined prepend-inner-icon="mdi-account-details-outline"
                              v-model="editedItem.vacation" label="Vacation"></v-text-field>
                          </v-col>
                        </v-row>
                        <center>
                          <h1 style="font-weight: bold">Armes</h1>
                        </center>
                        <center>
                          <h2 style="font-weight: bold">REVOLVER 9mm</h2>
                        </center>
                        <center>
                          <h3 style="font-weight: bold">RJ131910645</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field outlined prepend-inner-icon="mdi-account-details-outline"
                              v-model="editedItem.RJ131910645etat" label="Etat"></v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.RJ131910645anomalies" label="Anomalies">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.RJ131910645observations" label="Observations">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <h3>Date de sortie</h3>
                            <input type="date" v-model="editedItem.RJ131910645dateSortie" class="datepicker" />

                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <h3>Date de retour</h3>
                            <input type="date" v-model="editedItem.RJ131910645dateRetour" class="datepicker" />

                          </v-col>
                        </v-row>
                        <center>
                          <h3 style="font-weight: bold">RJ120205375</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.RJ120205375etat" label="Etat"></v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.RJ120205375anomalies" label="Anomalies">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.RJ120205375observations" label="Observations">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <h3>Date de sortie</h3>
                            <input type="date" v-model="editedItem.RJ120205375dateSortie" class="datepicker" />

                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <h3>Date de retour</h3>
                            <input type="date" v-model="editedItem.RJ120205375dateRetour" class="datepicker" />

                          </v-col>
                        </v-row>
                        <center>
                          <h2 style="font-weight: bold">REVOLVER 6mm</h2>
                        </center>
                        <center>
                          <h3 style="font-weight: bold">RL130410466</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.RL130410466etat" label="Etat"></v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.RL130410466anomalies" label="Anomalies">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.RL130410466observations" label="Observations">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <h3>Date de sortie</h3>
                            <input type="date" v-model="editedItem.RL130410466dateSortie" class="datepicker" />

                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <h3>Date de retour</h3>
                            <input type="date" v-model="editedItem.RL130410466dateRetour" class="datepicker" />

                          </v-col>
                        </v-row>
                        <v-spacer></v-spacer>
                        <v-col cols="12" sm="10" md="10" v-if="editedItem.autresArmes != null">
                          <h2 style="color: red; text-align: center;text-decoration: underline;">Autres armes</h2>
                          <div v-for="(item, key) of editedItem.autresArmes" v-bind:key="item.cle" v-bind:video="item">
                            <v-row style="color: red; text-align: center;">Arme: <h4>{{ key }}</h4>
                            </v-row>
                            <br>
                            <div v-for="(item1, key) of item" v-bind:key="item1.cle" v-bind:video="item1">
                              <v-col cols="12" sm="10" md="10">
                                <v-row style="color: red; text-align: center;">Modèle: <h4>{{ key }}</h4>
                                </v-row>
                                <br>
                                <v-col cols="12" sm="10" md="10">
                                  <v-row>Etat: <h4>{{ item1.etat }}</h4>
                                  </v-row>
                                  <v-row>Anomalie: <h4>{{ item1.anomalies }}</h4>
                                  </v-row>
                                  <v-row> Date de sortie: <h4>{{ item1.dateSortie }}</h4>
                                  </v-row>
                                  <v-row> Date de retour: <h4>{{ item1.dateRetour }}</h4>
                                  </v-row>
                                  <v-row> Observations: <h4>{{ item1.observations }}</h4>
                                  </v-row>
                                </v-col>
                              </v-col>
                            </div>
                          </div>
                        </v-col>
                        <v-divider></v-divider>
                        <br>
                        <center>
                          <h1 style="font-weight: bold">Munitions</h1>
                        </center>
                        <center>
                          <h2 style="font-weight: bold">
                            Cartouches à blancs 9 mm
                          </h2>
                        </center>
                        <center>
                          <h3 style="font-weight: bold">TG3529AO</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOrecues" label="Nombre de munitions reçues">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOutilisees" label="Nombre de munitions utilisées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOrestantes" label="Nombre de munitions restantes">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOusees" label="Nombre de munitions usées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOdetruites" label="Nombre de munitions détruites">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOobservations" label="Observations">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <center>
                          <h3 style="font-weight: bold">TG6768AW</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWrecues" label="Nombre de munitions reçues">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWutilisees" label="Nombre de munitions utilisées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWrestantes" label="Nombre de munitions restantes">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWusees" label="Nombre de munitions usées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWdetruites" label="Nombre de munitions détruites">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWobservations" label="Observations">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <center>
                          <h2 style="font-weight: bold">
                            Cartouches à blancs 6 mm
                          </h2>
                        </center>
                        <center>
                          <h3 style="font-weight: bold">TG3529AO</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOrecues6mm" label="Nombre de munitions reçues"></v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOutilisees6mm" label="Nombre de munitions utilisées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOrestantes6mm" label="Nombre de munitions restantes">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOusees6mm" label="Nombre de munitions usées"></v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOdetruites6mm" label="Nombre de munitions détruites">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOobservations6mm" label="Observations">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <center>
                          <h3 style="font-weight: bold">TG6768AW</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWrecues6mm" label="Nombre de munitions reçues"></v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWutilisees6mm" label="Nombre de munitions utilisées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWrestantes6mm" label="Nombre de munitions restantes">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWusees6mm" label="Nombre de munitions usées"></v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWdetruites6mm" label="Nombre de munitions détruites">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWobservations6mm" label="Observations">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <center>
                          <h2 style="font-weight: bold">Fusées détonnantes</h2>
                        </center>
                        <center>
                          <h3 style="font-weight: bold">TG3529AO</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOrecuesDetonnants" label="Nombre de munitions reçues">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOutiliseesDetonnants" label="Nombre de munitions utilisées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOrestantesDetonnants" label="Nombre de munitions restantes">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOuseesDetonnants" label="Nombre de munitions usées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOdetruitesDetonnants" label="Nombre de munitions détruites">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify" v-model="
                              editedItem.TG3529AOobservationsDetonnants
                            " label="Observations"></v-text-field>
                          </v-col>
                        </v-row>
                        <center>
                          <h3 style="font-weight: bold">TG6768AW</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWrecuesDetonnants" label="Nombre de munitions reçues">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWutiliseesDetonnants" label="Nombre de munitions utilisées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWrestantesDetonnants" label="Nombre de munitions restantes">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWuseesDetonnants" label="Nombre de munitions usées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWdetruitesDetonnants" label="Nombre de munitions détruites">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify" v-model="
                              editedItem.TG6768AWobservationsDetonnants
                            " label="Observations"></v-text-field>
                          </v-col>
                        </v-row>
                        <center>
                          <h2 style="font-weight: bold">Fusées crépitantes</h2>
                        </center>
                        <center>
                          <h3 style="font-weight: bold">TG3529AO</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOrecuesCrepitants" label="Nombre de munitions reçues">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOutilisees" label="Nombre de munitions utilisées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOrestantesCrepitants" label="Nombre de munitions restantes">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOuseesCrepitants" label="Nombre de munitions usées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOdetruitesCrepitants" label="Nombre de munitions détruites">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify" v-model="
                              editedItem.TG3529AOobservationsCrepitants
                            " label="Observations"></v-text-field>
                          </v-col>
                        </v-row>
                        <center>
                          <h3 style="font-weight: bold">TG6768AW</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWrecuesCrepitants" label="Nombre de munitions reçues">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWutiliseesCrepitants" label="Nombre de munitions utilisées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWrestantesCrepitants" label="Nombre de munitions restantes">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWuseesCrepitants" label="Nombre de munitions usées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWdetruitesCrepitants" label="Nombre de munitions détruites">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify" v-model="
                              editedItem.TG6768AWobservationsCrepitants
                            " label="Observations"></v-text-field>
                          </v-col>
                        </v-row>
                        <center>
                          <h2 style="font-weight: bold">
                            Autres numitions d'effarouchement
                          </h2>
                        </center>
                        <center>
                          <h3 style="font-weight: bold">TG3529AO</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOrecuesAutres" label="Nombre de munitions reçues">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOutiliseesAutres" label="Nombre de munitions utilisées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOrestantesAutres" label="Nombre de munitions restantes">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOuseesAutres" label="Nombre de munitions usées"></v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOdetruitesAutres" label="Nombre de munitions détruites">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG3529AOobservationsAutres" label="Observations">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <center>
                          <h3 style="font-weight: bold">TG6768AW</h3>
                        </center>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWrecuesAutres" label="Nombre de munitions reçues">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWutiliseesAutres" label="Nombre de munitions utilisées">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWrestantesAutres" label="Nombre de munitions restantes">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWuseesAutres" label="Nombre de munitions usées"></v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWdetruitesAutres" label="Nombre de munitions détruites">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.TG6768AWobservationsAutres" label="Observations">
                            </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-select :items="items2" prepend-inner-icon="mdi-format-align-justify"
                              v-model="editedItem.status" label="Statut"></v-select>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            Détails du statut
                            <vue-editor v-model="editedItem.detailStatut" label="Détails du statut"> </vue-editor>
                          </v-col>
                        </v-row>
                        <v-divider></v-divider>
                        <v-spacer></v-spacer>
                        <v-col cols="12" sm="10" md="10" v-if="editedItem.autresMunitions != null">
                          <h2 style="color: red; text-align: center;text-decoration: underline;">Autres munitions</h2>
                          <div v-for="(item, key) of editedItem.autresMunitions" v-bind:key="item.cle"
                            v-bind:video="item">
                            <v-row style="color: red; text-align: center;">Munition: <h4>{{ key }}</h4>
                            </v-row>
                            <br>
                            <div v-for="(item1, key) of item" v-bind:key="item1.cle" v-bind:video="item1">
                              <v-col cols="12" sm="10" md="10">
                                <v-row style="color: red; text-align: center;">Modèle: <h4>{{ key }}</h4>
                                </v-row>
                                <br>
                                <v-col cols="12" sm="10" md="10">
                                  <v-row>Reçues: <h4>{{ item1.recues }}</h4>
                                  </v-row>
                                  <v-row>Utilisées: <h4>{{ item1.utilisees }}</h4>
                                  </v-row>
                                  <v-row>Restantes: <h4>{{ item1.restantes }}</h4>
                                  </v-row>
                                  <v-row>Usées: <h4>{{ item1.usees }}</h4>
                                  </v-row>
                                  <v-row> Détruites: <h4>{{ item1.detruites }}</h4>
                                  </v-row>
                                  <v-row> Observations: <h4>{{ item1.observations }}</h4>
                                  </v-row>
                                </v-col>
                              </v-col>
                            </div>
                          </div>
                        </v-col>
                        <v-divider></v-divider>
                        <br>
                        <v-col cols="12" sm="10" md="10"
                          v-if="editedItem.customFieldsData && editedItem.customFieldsData.length > 0">
                          <h2 style="color: red; text-align: center;">Champs personnalisés</h2>
                          <div v-for="item of editedItem.customFieldsData" v-bind:key="item.cle" v-bind:video="item">

                            <v-row v-if="item.type == 'Zone de texte'">
                              <v-col cols="12" sm="10" md="10">
                                <h4>{{ item.titre }}</h4>
                                <vue-editor
                                  v-model="editedItem.customFieldsData[editedItem.customFieldsData.indexOf(item)].valeur">
                                </vue-editor>

                              </v-col>
                            </v-row>

                            <v-row v-if="item.type == 'Texte' || item.type == 'Numérique'">
                              <v-col cols="12" sm="10" md="10">
                                <h4>{{ item.titre }}</h4>
                                <v-text-field prepend-inner-icon="mdi-format-align-justify" :disabled="loading"
                                  v-model="editedItem.customFieldsData[editedItem.customFieldsData.indexOf(item)].valeur">
                                </v-text-field>
                              </v-col>
                            </v-row>

                            <v-row v-if="item.type == 'Date'">
                              <v-col cols="12" sm="10" md="10">
                                <h4>{{ item.titre }}</h4>

                                <v-text-field
                                  v-model="editedItem.customFieldsData[editedItem.customFieldsData.indexOf(item)].valeur"
                                  readonly v-bind="attrs" v-on="on"></v-text-field>

                              </v-col>
                            </v-row>

                            <v-row v-if="item.type == 'Case à cocher'">
                              <v-col cols="12" sm="10" md="10">
                                <v-checkbox
                                  v-model="editedItem.customFieldsData[editedItem.customFieldsData.indexOf(item)].valeur"
                                  :label="item.titre"></v-checkbox>
                              </v-col>
                            </v-row>

                            <v-row v-if="item.type == 'Liste déroulante'">
                              <v-col cols="12" sm="10" md="10">
                                <v-select prepend-inner-icon="mdi-apps" :label="item.titre" :disabled="loading"
                                  v-model="editedItem.customFieldsData[editedItem.customFieldsData.indexOf(item)].valeur"
                                  :items="item.listData"></v-select>
                              </v-col>
                            </v-row>

                            <v-row v-if="item.type == 'Fichier'">
                              <v-col cols="12" sm="10" md="10">
                                <h4>{{ item.titre }}</h4>
                                <v-btn class="ma-2" color="primary"
                                  @click="() => openLink(editedItem.customFieldsData[editedItem.customFieldsData.indexOf(item)].valeur)"
                                  download>
                                  VOIR LE FICHIER
                                </v-btn>
                              </v-col>
                            </v-row>

                          </div>
                        </v-col>
                        <v-divider></v-divider>
                        <v-spacer></v-spacer>
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <h4>Commentaire de l'agent</h4>

                            <vue-editor v-model="editedItem.commentaires"></vue-editor>


                          </v-col>

                        </v-row>
                        <br>
                        <div v-if="editedItem.imagesJoined != null && editedItem.imagesJoined.length > 0">
                          <v-divider></v-divider>
                          <h4> Images envoyées </h4>
                          <v-row>
                            <div v-for="item of editedItem.imagesJoined" v-bind:key="item.cle" v-bind:video="item">
                              <v-avatar size="100px" class="my-2" @click="() => openLink(item)">
                                <img :src="item" />
                              </v-avatar>
                              &nbsp;&nbsp;
                            </div>

                          </v-row>
                        </div>
                        <br>
                        <div v-if="editedItem.documentsJoined != null && editedItem.documentsJoined.length > 0">
                          <v-divider></v-divider>
                          <h4> Documents envoyées</h4>
                          <v-row>
                            <div v-for="item of editedItem.documentsJoined" v-bind:key="item.cle" v-bind:video="item">
                              <v-btn class="ma-2" color="error" @click="() => openLink(item)" download>
                                <b> VOIR LE FICHIER {{ editedItem.documentsJoined.indexOf(item) + 1 }}</b>
                              </v-btn>
                              &nbsp;&nbsp;
                            </div>
                          </v-row>
                        </div>

                      </v-col>
                    </v-row>
                  </v-form>
                </v-container>
              </v-card-text>

              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn :disabled="loading" color="blue darken-1" text @click="closeView">Quitter</v-btn>
                <v-btn :disabled="loading" color="blue darken-1" text @click="save">Enregistrer</v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>
          <v-dialog v-model="dialogMail" max-width="450px">
            <v-card>
              <v-card-title>
                <span class="headline">Envoyer le formulaire par email</span>
              </v-card-title>
              <v-card-text>
                <v-container>
                  <v-form v-bind:disabled="loading" lazy-validation ref="dialogForm">
                    <v-row>
                      <v-col cols="12">
                        <v-row>
                          <v-col cols="12" sm="10" md="10">
                            <v-text-field prepend-inner-icon="mdi-email-outline" v-model="email"
                              label="Email du destinataire" :rules="titleRule"></v-text-field>
                          </v-col>
                        </v-row>
                      </v-col>
                    </v-row>
                  </v-form>
                </v-container>
              </v-card-text>
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn :disabled="loading" color="blue darken-1" text @click="closeMail">Quitter</v-btn>
                <v-btn :disabled="loading" color="blue darken-1" text @click="sendMail">Enregistrer</v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>
          <v-spacer></v-spacer>
          <v-btn :disabled="loading1" color="blue" class="mb-2 white--text" @click="addItem()" fab dark small
            v-bind="attrs" v-on="on">
            <v-icon dark>
              mdi-plus
            </v-icon>
          </v-btn>
          <v-btn text icon class="mb-2 ml-2" @click="initialize">
            <v-icon>mdi-refresh</v-icon>
          </v-btn>
        </v-toolbar>
      </template>
      <template v-slot:[`item.idForm`]="{ item }">
        <v-chip color="blue" style="color: aliceblue" @click="viewItem(item)">{{ item.idForm }}
        </v-chip>
      </template>
      <template v-slot:[`item.status`]="{ value }">
        <v-chip v-if="value == 'En cours'" color="green" style="color: aliceblue">{{ value }}</v-chip>
        <v-chip v-if="value == 'Validé'" color="blue" style="color: aliceblue">{{ value }}</v-chip>
        <v-chip v-if="value == 'Non validé'" color="red" style="color: aliceblue">{{ value }}</v-chip>
        <v-chip v-if="value == 'Non approuvé'" color="red" style="color: aliceblue">{{ value }}</v-chip>
        <v-chip v-if="value == 'Approuvé'" color="blue" style="color: aliceblue">{{ value }}</v-chip>
        <v-chip
          v-if="value != 'Approuvé' && value != 'Non approuvé' && value != 'Validé' && value != 'Non validé' && value != 'En cours'"
          color="grey" style="color: aliceblue">{{ value }}</v-chip>
      </template>
      <template v-slot:[`item.documentAccompagne`]="{ value }">
        <v-btn v-if="value != ''" class="ma-2" color="error" @click="() => openLink(value)" download>
          VOIR
        </v-btn>
      </template>
      <template v-slot:[`body.prepend`]="{ headers }">
        <tr class="mx-0 px-0">
          <td :colspan="headers.length" class="mx-0 px-0">
            <v-text-field v-model="search" prepend-inner-icon="mdi-magnify" label="Rechercher" single-line hide-details
              filled class="px-0 mx-0" />
          </td>
        </tr>
      </template>

      <template v-slot:[`item.actions`]="{ item }">
        <v-icon medium class="mr-2" @click="exportFormToPDF(item.idForm)" color="red">
          mdi-file-download-outline
        </v-icon>&nbsp;&nbsp;
        <v-icon medium class="mr-2" @click="printForm(item.idForm)" color="success">
          mdi-printer-settings
        </v-icon>&nbsp;&nbsp;
        <v-icon medium @click="viewItem(item)" color="blue">
          mdi-eye-settings-outline
        </v-icon>&nbsp;&nbsp;
        <v-icon medium @click="viewMail(item)" color="gray">
          mdi-email-fast-outline
        </v-icon>&nbsp;&nbsp;
        <v-icon medium color="red" class="mr-2" @click="deleteItem(item)">
          mdi-delete
        </v-icon>
      </template>


      <template v-slot:no-data>
        <v-btn color="primary" @click="initialize">Réinitialiser</v-btn>
      </template>
    </v-data-table>

    <v-snackbar v-model="snack" :timeout="3000" :color="snackColor">
      {{ snackText }}
      <template v-slot:action="{ attrs }">
        <v-btn v-bind="attrs" text @click="snack = false">Fermer</v-btn>
      </template>
    </v-snackbar>
  </v-card>
</template>

<script>
import moment from 'moment';

import { mapActions, mapGetters } from "vuex";
const Excel = require("exceljs");
import { firestore } from "firebase";
import * as fs from "file-saver";
import { storage } from "firebase";
import jsPDF from "jspdf";
import { VueEditor } from "vue2-editor";
import AXIOS from "axios";

export default {
  components: { VueEditor },
  data() {
    return {

      snack: false,
      snackColor: "",
      snackText: "",
      search: "",
      loading: true,
      loading1: false,
      loading2: false,
      dialogAdd: false,
      dialog: false,
      dialogView: false,
      dialogMail: false,
      email: "",
      formId: "",
      headers: [{ text: "ID", value: "idForm" },
      {
        text: "Intitulé",
        align: "start",
        sortable: true,
        value: "intitulePassation",
      },
      {
        text: "Nom et prénoms",
        align: "start",
        sortable: true,
        value: "userName",
      },

      { text: "Date et heure d'envoi", value: "dateEnvoi" },

      // { text: "Commentaires", value: "commentaireAdmin" },
      { text: "Statut", value: "status", sortable: true },
      { text: "Actions", value: "actions", sortable: false },
      ],
      titleRule: [(v) => !!v || "Champ obligatoire"],
     items2:
        localStorage.getItem("role") == "Superviseur (Chef Service)"
          ? ["Terminé","Validé", "Non validé", "En cours"]
          : ["Terminé","Ouvert", "Ouvert", "Approuvé", "Refusé", "Réglé", "Non réglé(pièces en commande)", "Non réglé (matériel à changer)", "Non réglé (pas de contrat)", "En cours"],
     editedIndex: -1,
      editedItem: {
        autresArmes: "",
        autresMunitions: "",
        commentaires: "",
        roleCommentateur: "",
        commentedBy: "",
        imagesJoined: "",
        documentsJoined: "",
        intitulePassation: "",
        vacation: "",
        nomEtPrenomAgentEntrant: "",
        nomEtPrenomAgentSortant: "",
        detailStatut: "",
        RJ131910645etat: "",
        RJ131910645anomalies: "",
        RJ131910645dateSortie: "",
        RJ131910645dateRetour: "",
        RJ131910645observations: "",

        RJ120205375etat: "",
        RJ120205375anomalies: "",
        RJ120205375dateSortie: "",
        RJ120205375dateRetour: "",
        RJ120205375observations: "",

        RL130410466etat: "",
        RL130410466anomalies: "",
        RL130410466dateSortie: "",
        RL130410466dateRetour: "",
        RL130410466observations: "",

        TG3529AOrecues: "",
        TG3529AOutilisees: "",
        TG3529AOrestantes: "",
        TG3529AOusees: "",
        TG3529AOdetruites: "",
        // TG3529AOdateSortie: "",
        // TG3529AOdateRetour: "",
        TG3529AOobservations: "",

        TG6768AWrecues: "",
        TG6768AWutilisees: "",
        TG6768AWrestantes: "",
        TG6768AWusees: "",
        TG6768AWdetruites: "",
        // TG6768AWdateSortie: "",
        // TG6768AWdateRetour: "",
        TG6768AWobservations: "",

        TG3529AOrecues6mm: "",
        TG3529AOutilisees6mm: "",
        TG3529AOrestantes6mm: "",
        TG3529AOusees6mm: "",
        TG3529AOdetruites6mm: "",
        // TG3529AOdateSortie6mm: "",
        // TG3529AOdateRetour6mm: "",
        TG3529AOobservations6mm: "",

        TG6768AWrecues6mm: "",
        TG6768AWutilisees6mm: "",
        TG6768AWrestantes6mm: "",
        TG6768AWusees6mm: "",
        TG6768AWdetruites6mm: "",
        // TG6768AWdateSortie6mm: "",
        // TG6768AWdateRetour6mm: "",
        TG6768AWobservations6mm: "",

        TG3529AOrecuesDetonnants: "",
        TG3529AOutiliseesDetonnants: "",
        TG3529AOrestantesDetonnants: "",
        TG3529AOuseesDetonnants: "",
        TG3529AOdetruitesDetonnants: "",
        // TG3529AOdateSortieDetonnants: "",
        // TG3529AOdateRetourDetonnants: "",
        TG3529AOobservationsDetonnants: "",

        TG6768AWrecuesDetonnants: "",
        TG6768AWutiliseesDetonnants: "",
        TG6768AWrestantesDetonnants: "",
        TG6768AWuseesDetonnants: "",
        TG6768AWdetruitesDetonnants: "",
        // TG6768AWdateSortieDetonnants: "",
        // TG6768AWdateRetourDetonnants: "",
        TG6768AWobservationsDetonnants: "",

        TG3529AOrecuesCrepitants: "",
        TG3529AOutiliseesCrepitants: "",
        TG3529AOrestantesCrepitants: "",
        TG3529AOuseesCrepitants: "",
        TG3529AOdetruitesCrepitants: "",
        // TG3529AOdateSortieCrepitants: "",
        // TG3529AOdateRetourCrepitants: "",
        TG3529AOobservationsCrepitants: "",

        TG6768AWrecuesCrepitants: "",
        TG6768AWutiliseesCrepitants: "",
        TG6768AWrestantesCrepitants: "",
        TG6768AWuseesCrepitants: "",
        TG6768AWdetruitesCrepitants: "",
        // TG6768AWdateSortieCrepitants: "",
        // TG6768AWdateRetourCrepitants: "",
        TG6768AWobservationsCrepitants: "",

        TG3529AOrecuesAutres: "",
        TG3529AOutiliseesAutres: "",
        TG3529AOrestantesAutres: "",
        TG3529AOuseesAutres: "",
        TG3529AOdetruitesAutres: "",
        // TG3529AOdateSortieAutres: "",
        // TG3529AOdateRetourAutres: "",
        TG3529AOobservationsAutres: "",

        TG6768AWrecuesAutres: "",
        TG6768AWutiliseesAutres: "",
        TG6768AWrestantesAutres: "",
        TG6768AWuseesAutres: "",
        TG6768AWdetruitesAutres: "",
        // TG6768AWdateSortieAutres: "",
        // TG6768AWdateRetourAutres: "",
        TG6768AWobservationsAutres: "",

        userId: "",
        userName: "",
        status: "",
        commentaireAdmin: "",
        dateEnvoi: "",
        id: "",
      },
      defaultItem: {
        autresArmes: "",
        autresMunitions: "",
        commentaires: "",
        roleCommentateur: "",
        commentedBy: "",
        imagesJoined: [],
        documentsJoined: [],
        intitulePassation: "",
        vacation: "",
        nomEtPrenomAgentEntrant: "",
        nomEtPrenomAgentSortant: "",
        detailStatut: "",
        RJ131910645etat: "",
        RJ131910645anomalies: "",
        RJ131910645dateSortie: "",
        RJ131910645dateRetour: "",
        RJ131910645observations: "",

        RJ120205375etat: "",
        RJ120205375anomalies: "",
        RJ120205375dateSortie: "",
        RJ120205375dateRetour: "",
        RJ120205375observations: "",

        RL130410466etat: "",
        RL130410466anomalies: "",
        RL130410466dateSortie: "",
        RL130410466dateRetour: "",
        RL130410466observations: "",

        TG3529AOrecues: "",
        TG3529AOutilisees: "",
        TG3529AOrestantes: "",
        TG3529AOusees: "",
        TG3529AOdetruites: "",
        // TG3529AOdateSortie: "",
        // TG3529AOdateRetour: "",
        TG3529AOobservations: "",

        TG6768AWrecues: "",
        TG6768AWutilisees: "",
        TG6768AWrestantes: "",
        TG6768AWusees: "",
        TG6768AWdetruites: "",
        // TG6768AWdateSortie: "",
        // TG6768AWdateRetour: "",
        TG6768AWobservations: "",

        TG3529AOrecues6mm: "",
        TG3529AOutilisees6mm: "",
        TG3529AOrestantes6mm: "",
        TG3529AOusees6mm: "",
        TG3529AOdetruites6mm: "",
        // TG3529AOdateSortie6mm: "",
        // TG3529AOdateRetour6mm: "",
        TG3529AOobservations6mm: "",

        TG6768AWrecues6mm: "",
        TG6768AWutilisees6mm: "",
        TG6768AWrestantes6mm: "",
        TG6768AWusees6mm: "",
        TG6768AWdetruites6mm: "",
        // TG6768AWdateSortie6mm: "",
        // TG6768AWdateRetour6mm: "",
        TG6768AWobservations6mm: "",

        TG3529AOrecuesDetonnants: "",
        TG3529AOutiliseesDetonnants: "",
        TG3529AOrestantesDetonnants: "",
        TG3529AOuseesDetonnants: "",
        TG3529AOdetruitesDetonnants: "",
        // TG3529AOdateSortieDetonnants: "",
        // TG3529AOdateRetourDetonnants: "",
        TG3529AOobservationsDetonnants: "",

        TG6768AWrecuesDetonnants: "",
        TG6768AWutiliseesDetonnants: "",
        TG6768AWrestantesDetonnants: "",
        TG6768AWuseesDetonnants: "",
        TG6768AWdetruitesDetonnants: "",
        // TG6768AWdateSortieDetonnants: "",
        // TG6768AWdateRetourDetonnants: "",
        TG6768AWobservationsDetonnants: "",

        TG3529AOrecuesCrepitants: "",
        TG3529AOutiliseesCrepitants: "",
        TG3529AOrestantesCrepitants: "",
        TG3529AOuseesCrepitants: "",
        TG3529AOdetruitesCrepitants: "",
        // TG3529AOdateSortieCrepitants: "",
        // TG3529AOdateRetourCrepitants: "",
        TG3529AOobservationsCrepitants: "",

        TG6768AWrecuesCrepitants: "",
        TG6768AWutiliseesCrepitants: "",
        TG6768AWrestantesCrepitants: "",
        TG6768AWuseesCrepitants: "",
        TG6768AWdetruitesCrepitants: "",
        // TG6768AWdateSortieCrepitants: "",
        // TG6768AWdateRetourCrepitants: "",
        TG6768AWobservationsCrepitants: "",

        TG3529AOrecuesAutres: "",
        TG3529AOutiliseesAutres: "",
        TG3529AOrestantesAutres: "",
        TG3529AOuseesAutres: "",
        TG3529AOdetruitesAutres: "",
        // TG3529AOdateSortieAutres: "",
        // TG3529AOdateRetourAutres: "",
        TG3529AOobservationsAutres: "",

        TG6768AWrecuesAutres: "",
        TG6768AWutiliseesAutres: "",
        TG6768AWrestantesAutres: "",
        TG6768AWuseesAutres: "",
        TG6768AWdetruitesAutres: "",
        // TG6768AWdateSortieAutres: "",
        // TG6768AWdateRetourAutres: "",
        TG6768AWobservationsAutres: "",

        userId: "",
        userName: "",
        status: "En cours",
        commentaireAdmin: "",
        dateEnvoi: "",
        id: "",
      }, defaultItemInit: {
        autresArmes: "",
        autresMunitions: "",
        commentaires: "",
        roleCommentateur: "",
        commentedBy: "",
        imagesJoined: [],
        documentsJoined: [],
        intitulePassation: "",
        vacation: "",
        nomEtPrenomAgentEntrant: "",
        nomEtPrenomAgentSortant: "",
        detailStatut: "",
        RJ131910645etat: "",
        RJ131910645anomalies: "",
        RJ131910645dateSortie: "",
        RJ131910645dateRetour: "",
        RJ131910645observations: "",

        RJ120205375etat: "",
        RJ120205375anomalies: "",
        RJ120205375dateSortie: "",
        RJ120205375dateRetour: "",
        RJ120205375observations: "",

        RL130410466etat: "",
        RL130410466anomalies: "",
        RL130410466dateSortie: "",
        RL130410466dateRetour: "",
        RL130410466observations: "",

        TG3529AOrecues: "",
        TG3529AOutilisees: "",
        TG3529AOrestantes: "",
        TG3529AOusees: "",
        TG3529AOdetruites: "",
        // TG3529AOdateSortie: "",
        // TG3529AOdateRetour: "",
        TG3529AOobservations: "",

        TG6768AWrecues: "",
        TG6768AWutilisees: "",
        TG6768AWrestantes: "",
        TG6768AWusees: "",
        TG6768AWdetruites: "",
        // TG6768AWdateSortie: "",
        // TG6768AWdateRetour: "",
        TG6768AWobservations: "",

        TG3529AOrecues6mm: "",
        TG3529AOutilisees6mm: "",
        TG3529AOrestantes6mm: "",
        TG3529AOusees6mm: "",
        TG3529AOdetruites6mm: "",
        // TG3529AOdateSortie6mm: "",
        // TG3529AOdateRetour6mm: "",
        TG3529AOobservations6mm: "",

        TG6768AWrecues6mm: "",
        TG6768AWutilisees6mm: "",
        TG6768AWrestantes6mm: "",
        TG6768AWusees6mm: "",
        TG6768AWdetruites6mm: "",
        // TG6768AWdateSortie6mm: "",
        // TG6768AWdateRetour6mm: "",
        TG6768AWobservations6mm: "",

        TG3529AOrecuesDetonnants: "",
        TG3529AOutiliseesDetonnants: "",
        TG3529AOrestantesDetonnants: "",
        TG3529AOuseesDetonnants: "",
        TG3529AOdetruitesDetonnants: "",
        // TG3529AOdateSortieDetonnants: "",
        // TG3529AOdateRetourDetonnants: "",
        TG3529AOobservationsDetonnants: "",

        TG6768AWrecuesDetonnants: "",
        TG6768AWutiliseesDetonnants: "",
        TG6768AWrestantesDetonnants: "",
        TG6768AWuseesDetonnants: "",
        TG6768AWdetruitesDetonnants: "",
        // TG6768AWdateSortieDetonnants: "",
        // TG6768AWdateRetourDetonnants: "",
        TG6768AWobservationsDetonnants: "",

        TG3529AOrecuesCrepitants: "",
        TG3529AOutiliseesCrepitants: "",
        TG3529AOrestantesCrepitants: "",
        TG3529AOuseesCrepitants: "",
        TG3529AOdetruitesCrepitants: "",
        // TG3529AOdateSortieCrepitants: "",
        // TG3529AOdateRetourCrepitants: "",
        TG3529AOobservationsCrepitants: "",

        TG6768AWrecuesCrepitants: "",
        TG6768AWutiliseesCrepitants: "",
        TG6768AWrestantesCrepitants: "",
        TG6768AWuseesCrepitants: "",
        TG6768AWdetruitesCrepitants: "",
        // TG6768AWdateSortieCrepitants: "",
        // TG6768AWdateRetourCrepitants: "",
        TG6768AWobservationsCrepitants: "",

        TG3529AOrecuesAutres: "",
        TG3529AOutiliseesAutres: "",
        TG3529AOrestantesAutres: "",
        TG3529AOuseesAutres: "",
        TG3529AOdetruitesAutres: "",
        // TG3529AOdateSortieAutres: "",
        // TG3529AOdateRetourAutres: "",
        TG3529AOobservationsAutres: "",

        TG6768AWrecuesAutres: "",
        TG6768AWutiliseesAutres: "",
        TG6768AWrestantesAutres: "",
        TG6768AWuseesAutres: "",
        TG6768AWdetruitesAutres: "",
        // TG6768AWdateSortieAutres: "",
        // TG6768AWdateRetourAutres: "",
        TG6768AWobservationsAutres: "",

        userId: "",
        userName: "",
        status: "En cours",
        commentaireAdmin: "",
        dateEnvoi: "",
        id: "",
      },
    };
  },
  computed: {

    ...mapGetters({
      gestionSecurite: "gestionSecurite/getgestionSecurite",
    }),
    formTitle() {
      return "Modifier le statut";
    },
  },

  watch: {
    dialog(val) {
      val || this.close();
    },
    dialogView(val) {
      val || this.close();
    },
  },

  created() {
    this.initialize();
  },

  methods: {
    //mail sending//
    viewMail(item) {
      this.editedIndex = this.gestionSecurite.indexOf(item);
      this.editedItem = Object.assign({}, item);
      this.formId = this.editedItem.idForm;
      this.dialogMail = true;
    },
    closeMail() {
      this.dialogMail = false;
      this.$nextTick(() => {
        this.editedItem = Object.assign({}, this.defaultItem);
        this.editedIndex = -1;
      });
    },
    async sendMail() {
      if (!this.$refs.dialogForm.validate()) return;
      this.loading = true;
      let Columns = [
        {
          header: "Nom et prénoms de l'agent",
          key: "userName",
        },
        {
          header: "Intitulé",
          key: "intitulePassation",
        }, { header: "Statut", key: "status" },
        { header: "Adresse email de l'agent", key: "userEmail" },
        { header: "Date et heure d'envoi", key: "dateEnvoi" },

        {
          header: "Vacation",
          key: "vacation",
        },
        {
          header: "Agent entrant",
          key: "nomEtPrenomAgentEntrant",
        },
        {
          header: "Agent sortant",
          key: "nomEtPrenomAgentSortant",
        },
        { header: "Etat (REVOLVER 9mm RJ131910645)", key: "RJ131910645etat" },
        {
          header: "Anomalies (REVOLVER 9mm RJ131910645)",
          key: "RJ131910645anomalies",
        },
        {
          header: "Date de sortie (REVOLVER 9mm RJ131910645)",
          key: "RJ131910645dateSortie",
        },
        {
          header: "Date de retour (REVOLVER 9mm RJ131910645)",
          key: "RJ131910645dateRetour",
        },
        {
          header: "Observations (REVOLVER 9mm RJ131910645)",
          key: "RJ131910645observations",
        },

        { header: "Etat (REVOLVER 9mm RJ120205375)", key: "RJ120205375etat" },
        {
          header: "Anomalies (REVOLVER 9mm RJ120205375)",
          key: "RJ120205375anomalies",
        },
        {
          header: "Date de sortie (REVOLVER 9mm RJ120205375)",
          key: "RJ120205375dateSortie",
        },
        {
          header: "Date de retour (REVOLVER 9mm RJ120205375)",
          key: "RJ120205375dateRetour",
        },
        {
          header: "Observations (REVOLVER 9mm RJ120205375)",
          key: "RJ120205375observations",
        },

        { header: "Etat (REVOLVER 6mm RL130410466)", key: "RJ120205375etat" },
        {
          header: "Anomalies (REVOLVER 6mm RL130410466)",
          key: "RL130410466anomalies",
        },
        {
          header: "Date de sortie (REVOLVER 6mm RL130410466)",
          key: "RL130410466dateSortie",
        },
        {
          header: "Date de retour (REVOLVER 6mm RL130410466)",
          key: "RL130410466dateRetour",
        },
        {
          header: "Observations (REVOLVER 6mm RL130410466)",
          key: "RL130410466observations",
        },

        {
          header: "Munitions reçues (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOrecues",
        },
        {
          header: "Munitions utilisées (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOutilisees",
        },
        {
          header: "Munitions restantes (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOrestantes",
        },
        {
          header: "Munitions usées (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOusees",
        },
        {
          header: "Munitions détruites (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOdetruites",
        },
        // {
        //   header: "Date de sortie (Cartouches à blancs 9mm TG3529AO)",
        //   key: "TG3529AOdateSortie",
        // },
        // {
        //   header: "Date de retour (Cartouches à blancs 9mm TG3529AO)",
        //   key: "TG3529AOdateRetour",
        // },
        {
          header: "Observations (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOobservations",
        },

        {
          header: "Munitions reçues (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWrecues",
        },
        {
          header: "Munitions utilisées (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWutilisees",
        },
        {
          header: "Munitions restantes (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWrestantes",
        },
        {
          header: "Munitions usées (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWusees",
        },
        {
          header: "Munitions détruites (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWdetruites",
        },
        // {
        //   header: "Date de sortie (Cartouches à blancs 9mm TG6768AW)",
        //   key: "TG6768AWdateSortie",
        // },
        // {
        //   header: "Date de retour (Cartouches à blancs 9mm TG6768AW)",
        //   key: "TG6768AWdateRetour",
        // },
        {
          header: "Observations (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWobservations",
        },

        {
          header: "Munitions reçues (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOrecues6mm",
        },
        {
          header: "Munitions utilisées (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOutilisees6mm",
        },
        {
          header: "Munitions restantes (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOrestantes6mm",
        },
        {
          header: "Munitions usées (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOusees6mm",
        },
        {
          header: "Munitions détruites (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOdetruites6mm",
        },
        // {
        //   header: "Date de sortie (Cartouches à blancs 6mm TG3529AO)",
        //   key: "TG3529AOdateSortie6mm",
        // },
        // {
        //   header: "Date de retour (Cartouches à blancs 6mm TG3529AO)",
        //   key: "TG3529AOdateRetour6mm",
        // },
        {
          header: "Observations (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOobservations6mm",
        },

        {
          header: "Munitions reçues (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWrecues6mm",
        },
        {
          header: "Munitions utilisées (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWutilisees6mm",
        },
        {
          header: "Munitions restantes (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWrestantes6mm",
        },
        {
          header: "Munitions usées (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWusees6mm",
        },
        {
          header: "Munitions détruites (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWdetruites6mm",
        },
        // {
        //   header: "Date de sortie (Cartouches à blancs 6mm TG3529AO)",
        //   key: "TG6768AWdateSortie6mm",
        // },
        // {
        //   header: "Date de retour (Cartouches à blancs 6mm TG3529AO)",
        //   key: "TG6768AWdateRetour6mm",
        // },
        {
          header: "Observations (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWobservations6mm",
        },

        {
          header: "Munitions reçues (Fusées détonnantes TG3529AO)",
          key: "TG3529AOrecuesDetonnants",
        },
        {
          header: "Munitions utilisées (Fusées détonnantes TG3529AO)",
          key: "TG3529AOutiliseesDetonnants",
        },
        {
          header: "Munitions restantes (Fusées détonnantes TG3529AO)",
          key: "TG3529AOrestantesDetonnants",
        },
        {
          header: "Munitions usées (Fusées détonnantes TG3529AO)",
          key: "TG3529AOuseesDetonnants",
        },
        {
          header: "Munitions détruites (Fusées détonnantes TG3529AO)",
          key: "TG3529AOdetruitesDetonnants",
        },
        // {
        //   header: "Date de sortie (Fusées détonnantes TG3529AO)",
        //   key: "TG3529AOdateSortieDetonnants",
        // },
        // {
        //   header: "Date de retour (Fusées détonnantes TG3529AO)",
        //   key: "TG3529AOdateRetourDetonnants",
        // },
        {
          header: "Observations (Fusées détonnantes TG3529AO)",
          key: "TG3529AOobservationsDetonnants",
        },

        {
          header: "Munitions reçues (Fusées détonnantes TG6768AW)",
          key: "TG6768AWrecuesDetonnants",
        },
        {
          header: "Munitions utilisées (Fusées détonnantes TG6768AW)",
          key: "TG6768AWutiliseesDetonnants",
        },
        {
          header: "Munitions restantes (Fusées détonnantes TG6768AW)",
          key: "TG6768AWrestantesDetonnants",
        },
        {
          header: "Munitions usées (Fusées détonnantes TG6768AW)",
          key: "TG6768AWuseesDetonnants",
        },
        {
          header: "Munitions détruites (Fusées détonnantes TG6768AW)",
          key: "TG6768AWdetruitesDetonnants",
        },
        // {
        //   header: "Date de sortie (Fusées détonnantes TG6768AW)",
        //   key: "TG6768AWdateSortieDetonnants",
        // },
        // {
        //   header: "Date de retour (Fusées détonnantes TG6768AW)",
        //   key: "TG6768AWdateRetourDetonnants",
        // },

        {
          header: "Munitions reçues (Fusées crépitantes TG3529AO)",
          key: "TG3529AOrecuesCrepitants",
        },
        {
          header: "Munitions utilisées (Fusées crépitantes TG3529AO)",
          key: "TG3529AOutiliseesCrepitants",
        },
        {
          header: "Munitions restantes (Fusées crépitantes TG3529AO)",
          key: "TG3529AOrestantesCrepitants",
        },
        {
          header: "Munitions usées (Fusées crépitantes TG3529AO)",
          key: "TG3529AOuseesCrepitants",
        },
        {
          header: "Munitions détruites (Fusées crépitantes TG3529AO)",
          key: "TG3529AOdetruitesCrepitants",
        },
        // {
        //   header: "Date de sortie (Fusées crépitantes TG3529AO)",
        //   key: "TG3529AOdateSortieCrepitants",
        // },
        // {
        //   header: "Date de retour (Fusées crépitantes TG3529AO)",
        //   key: "TG3529AOdateRetourCrepitants",
        // },
        {
          header: "Observations (Fusées crépitantes TG3529AO)",
          key: "TG3529AOobservationsCrepitants",
        },

        {
          header: "Munitions reçues (Fusées crépitantes TG6768AW)",
          key: "TG6768AWrecuesCrepitants",
        },
        {
          header: "Munitions utilisées (Fusées crépitantes TG6768AW)",
          key: "TG6768AWutiliseesCrepitants",
        },
        {
          header: "Munitions restantes (Fusées crépitantes TG6768AW)",
          key: "TG6768AWrestantesCrepitants",
        },
        {
          header: "Munitions usées (Fusées crépitantes TG6768AW)",
          key: "TG6768AWuseesCrepitants",
        },
        {
          header: "Munitions détruites (Fusées crépitantes TG6768AW)",
          key: "TG6768AWdetruitesCrepitants",
        },
        // {
        //   header: "Date de sortie (Fusées crépitantes TG6768AW)",
        //   key: "TG6768AWdateSortieCrepitants",
        // },
        // {
        //   header: "Date de retour (Fusées crépitantes TG6768AW)",
        //   key: "TG6768AWdateRetourCrepitants",
        // },
        {
          header: "Observations (Fusées crépitantes TG6768AW)",
          key: "TG6768AWobservationsCrepitants",
        },

        {
          header:
            "Munitions reçues (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOrecuesAutres",
        },
        {
          header:
            "Munitions utilisées (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOutiliseesAutres",
        },
        {
          header:
            "Munitions restantes (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOrestantesAutres",
        },
        {
          header:
            "Munitions usées (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOuseesAutres",
        },
        {
          header:
            "Munitions détruites (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOdetruitesAutres",
        },
        // {
        //   header: "Date de sortie (Autres munitions d'effarouchement TG3529AO)",
        //   key: "TG3529AOdateSortieAutres",
        // },
        // {
        //   header: "Date de retour (Autres munitions d'effarouchement TG3529AO)",
        //   key: "TG3529AOdateRetourAutres",
        // },
        {
          header: "Observations (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOobservationsAutres",
        },

        {
          header:
            "Munitions reçues (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWrecuesAutres",
        },
        {
          header:
            "Munitions utilisées (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWutiliseesAutres",
        },
        {
          header:
            "Munitions restantes (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWrestantesAutres",
        },
        {
          header:
            "Munitions usées (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWuseesAutres",
        },
        {
          header:
            "Munitions détruites (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWdetruitesAutres",
        },
        // {
        //   header: "Date de sortie (Autres munitions d'effarouchement TG6768AW)",
        //   key: "TG6768AWdateSortieAutres",
        // },
        // {
        //   header: "Date de retour (Autres munitions d'effarouchement TG6768AW)",
        //   key: "TG6768AWdateRetourAutres",
        // },
        {
          header: "Observations (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWobservationsAutres",
        },
      ];
      this.loading = true;
      var m = new Date();
      var dateString =
        ("0" + m.getUTCDate()).slice(-2) + "-" +
        ("0" + (m.getUTCMonth() + 1)).slice(-2) + "-" +
        m.getUTCFullYear() + " " +
        ("0" + m.getUTCHours()).slice(-2) + ":" +
        ("0" + m.getUTCMinutes()).slice(-2);
      const snapshot = await firestore().collection("armesMunitions").where("idForm", "==", this.formId).get();
      const documents = snapshot.docs.map((doc) => doc.data());
      const doc = new jsPDF();
      let pageHeight = doc.internal.pageSize.height;
      doc.addImage("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAC5CAMAAABa+IDIAAABIFBMVEX////3/PYAjzb8/vv1/fUCkDn5+/b39AD///34/PX3/PgAkTbXIxYAjjoAfL35+/j68wAAer3u9/ICjDsKlEAhisAAe7Y1pmEMf73M5+ux3MGy2OOGwNrh8ebO6djV7Nwem08Ae8OVyNs0lcYZmkvX6+rj8vGBx5274Mkpj8Sm0eFBrGt5w5Z9vNM8mcmDxSZXqM9Enca+3hlmvIkPljRwviZatn6d1LJKrXFtstKVzR7a6QiSz6pgqsYinjJCqy5Wsyut1hbV5wzepZ/UJh349DveHRQtdTHRNSjoycGgO0HeVUrZRDnbhnowZpdySWHs29TadGpRXoJdhTD1zQw1lJVutcjNU0LhixMAi16gzkzQ5kPbZVdEh7VlrGwAgYkp1n3kAAAbJklEQVR4nO1dC3vaOLNGluxa8tpeCwzmYjDBBBIIJSUl0NL0tvud7r273/Wc71z+/784M7IhkIQExzTZp08mbRJIYvRac3lnNBKFwp9IzMcewH7ENL8OIE84/lxifh1AzCccfyr5mnA89hj2IV8Rjscewn7kK4HxJE/yJE/yJE/yJE/ysEIpRT4IpBC+eezBZBNmuIQxQgwhqGBhs7ZY9Hq9xXmtGboUhRGDMEM89jjvFByoIVvN8+EsKtkaiG2BaDZIXJn2as2WpNQgjz3Ou4QWaL83rcSWpum2peuagqDDQ03XbcCklaLBZNF87HFuFcYEB4Wh/Wlc0nEeEIEGSKx0PgAGfIVn4Ae6XoqHLdMlhJE/m44ZhivC/qSk7j3CUOOOo6gym0565yiLxXAyG1SiuITQNDvqNaUQ7LFHfkVooT+pwG0HZdJ0+LC1ymRx3gd7gB+a6LzwAzyYRPsfzmLEog16rcce+KWAC2LCqFVQo2xdobCiSU1KsiWFxSelbC0GNuheadoSRIg/g+0zl4W1ip2qlK7H0bBZMF3h3vZHJiG0IM8HccnWp6Bht/7yAwmVi4qNRoE2bg96fWK6rkHusmJeIMI0W+cTgDKrPW6wJBy8Dq1FGC3Qfq3ipCWzKokMF7GmzUJwYe5jeTBGXKM11c/QvnVLj4eS3qFRN19ELCJLX8jHsxSDhr0S6hNqVWURmoKAZL0KkBmT1AZ2dE4fZUbACGgTtEpXISOuSUFzXE3IfsWeScofHgsTsmdBnAbr0EsTQt1ceiGYy3tx3CcPHx/N5gxUykIc02YBqG4+BaeCmK2JNpR55jW7wKvWYsVELDvqy3tdQn0SQPmXTBgCSz+qtAyY3QebF0P2EkJraVOZgy4xLqtdZqweEz6Nm8RlfB+D3EXkRFcRUI/OTXGvl6XJHxF52l3zukS4i2jhsofRL0OEAzRzYOizljDu/oNrAoyfwD8I7+aJL8nGjaCtwRCcOLvPdTMKCytakltM7hmLAQRRBJ7I4OgKEGbIwVCQBzATs1WBuQDriBdm9vCnhArelRgy6NzrXAECEMlkIr94lCeiGSGv0q24f+/gBYoz7zLGSNdvdyS7cvOJS86n0iDsi2IRIVBdjB5R6N7bJDmtB11CuGw4AIRcu45rLIZ30uecElaQ5up6JczBjAjz/SpEEBk4ztHhNUMTxKCLofyCZkJcCfaBVLcS3huG4NxsOEGVE3PueI7fvcnQqFvrZc4Idhcip4gDUtkctmgIcdhxfAAiPSfw/OqNjlaI7KnN7kIhnqOdw3zkeBHBjwOYEcEb5WDeDuri5sn9YukJF+Y52jnMR0sUchgIYSOv3K4T2fFGXc873ubDc9LQ7QMQzZLSK6uVi0EwXvectncg4MsBDcon8oGpu5ADHSuHpT7NRR8I7zgj35uTuRNIcwwR8cEoIoiAfHQI7kovWr170atLoTAT9bHTEb4zNvFB9yGBEEL7qqRrzfK+LB07R926U663nSpnPHDmD1kLYiKMVeUqknkDbtcvjzkDv1U+YkBDIJbIB0RCyETDqk/czOcUCTfrgVcnfOy0nRNOBKsG3onJH4C0J2I0S6o4vTALuXyMAVPQDrjgAMerC4NSeQrB/eFq8mSGKzdWRd6fKSbX4bLjjCG6wxcfklyTGnWwkgeqAhFinqvKj97K+4KMHTpenQMrPG2PkMCbnL+BuaHkIVwXc2Ws41LTgvKc2TQjx57DOIGw3h5Tlc8K5jte1RAPgIS5Q7UGVZG5X00UICcEHAJSqkYChJFqAA6ZPwAQEUZo6aXze1R2rwgzjxxwvgSclXNMVe5EuDjwyqdMumuWgv6ME67WuXO+5JqQBS4c2JU9kDhhBk6DGESAiVeX4yZ87pVHlK/NNyOcG9ygpnE1Ec4jMlLLUffP0S+Fccc55oKQuuN1l3EQkt5x2zmVZLUkQWX1eD7yfX/UqO6tiCrMBS7jWLN90GohHadOBBHHyBiXzxIhx453Kg21dGTQ6nwESbDn4H/v9JjzfZS5DOHChJxpdsvdg7a6IXhfmBAA4qyXjDk7dTxfokbx6giCZdvxx/P5HDIXJxhzvof83aAYQyxrKvdhdkbYVkBQtdaBEEbHngqRVdAyLzg9ltiIY1LZ8D3Quj2UhpjEoK6VaqKwB2VlzEMbEaLuON216wlQn7nndeonMBt+owrsizDwWwY3D8eBM95D/i5aMZKTaD8UlaHXAmMXwBXrmzeGkAPPCRyv3JCMq0U8tCX4xMbgIPIDcc/V8kFvP1SbFjreGNeuqz7EkY0fge86Djyn04X4IcjyA35V8iMwn9wvTQY6ZoZ7qs0Ic+z4EAjJ4ZEzv7JiCACAEyMQtj4hYP9dz5sX8ppoaIPz1Sb58vSVEAONQ8AAR86pca1rC+sSRxx4F1F9HfDB0FIYmE9uDtNTjUnNPS0dA1sMvLlJBJ0Hfte4MjbKDXDLp0gq0wkBSLIrJRCak1y9ahCHInS+FZmbZaUXZHLsBVIwo+4F9WvaQtB3OSdyNSFYBCuPGTl1OrmUm5JQLekM8wx+QwQ/LoPfYpyD3t8UHeTIc6rGckKIUW0HHuMHTlDNA0QYC1U7qeW4xoYYgnU77VEoOB0DSbmu9pBCBmUf5iN1W5yeeifCkJ7XyAOEUKw56FHLEHTF4QUBcnrPq1KD0IbjHcMFug4S+WvX4bTuYTkinRLGTckNVoA8LA9LMcIB5uoDTAw56gOkEhR5ncEoveeFOR/BXDDJT50AE45rvwBW5B+yZSQB9wvzwueOn8drGa0I212HUoZrIkEIce/ZLEYgbXc6cEvgzjeoedUbmiapB+WGuzQSmBSDSXmFZO70QuApCoKaBRo2+9j9Y2tRVMJeS8tWLXKluFKZTXqLWjNkQOwg6ca2rQxASMNz5oQfdpzOIb8yI9iyzTptoImJzwIFqB7MR50jxzksZCPzarle1npT7AdNmkZ11chka2m3H/bLaZZdKkWVWa9PCtj3mmkLnhyVPfC9B23v+MpKIeKgYEW4xKhwGPWRD5weKJg34ltWUrYIEefTyMYoiGvQSeexrl0VPWl9wO7kSq+ZMcww6XtBlXPfOdp0XAoHOC7wAy4C4d0Rknp/dBpApjW/On13vIpQ67ZqFnAdAfvKsA1ZTwQrp/DD5ElbTY6mxdNFP4RRCHRnd983iA4KSb3snECUX2FROMC6TeAv4FoEO0AWOa/ij+rjIKhjrrgzEFdUknuu+hSxjcm+lGIRP9nKYFRjbNIiBKDiaLYIC4BF3G0vnGN90a9ySHCrYMsbOAAIbXg+TTKU4OAwWYPjEjLHQ5ahSkxpRU+HVwQTPzu7ePvu5fNX718k8v7V8+fv3p6daar7IdU51TiOi3LDJji0O2cEJk4cgMZIYLvArJa/n8wHiFt1HCYg+21DzgiunyENA/54MOIZdJiDatlF/ewtjP/V+w/Pvt2Q1cPXH94DoLeQzIOd4JK1WrfW7HjWq7WkiX4VIg69cXaIwLgIc+KDDdeX1BEnRPF2Ig5hpuQp5rgwL1T5EQDP6WE3A3XkpHLx7tWLD6+fqUE/U/It/ls+wB8kgJ69/vDi+buSVVRWpSXtphr458l5iBRAufIbBeh5I2g7Y9/rSGM1IQkORZGP521vLK8oUqZN1pJ9n4w/+fRsm3yb/AZi+vD8Qk+1TFkWapkdTWoh8vGb6wZg4lUfmDykJwd8hUMoJELII6fjlEf59jIw8v3GaJMZWFOqbzd/lvz4wyswnCLuFAG70tIdIwDm48fPnyUMkeHdxkCbDg3cz9jz6iZwR0/is6lipTPS8TxcJc1VBSLi+/RGpwgSFfqAhg7/P4DOrezlEg1azYtX7y6Kto5gEh9gW//xl+8+/fzT7x9/CEHT4YZjLVclhoQeOE7DhHkJPCwGXyqWmpGOh04tBwqcEfH95fhevHr+7iLWzrSirhWT2KEVtRI4sufvX6/PSmJEz56BlqFyqc0XCsg3qXz3z18+fpZIahkGGqMLEQLScSFHMOQlkLTcwEG1gmOesyhHCMzI6xfgky4wcBeLSltQ99Gci8k3+HxRuwA4L9QErWvZ6/cv316gdoFXBiDffbOSv3zz6Z+///Lx4w8/fP48bkN8I1wAr4VUgy81S02KcQJkzLzWK0mznUTA+H+9e3tR0oqoJeBZbS3d3bJJUbCTHAK7fnHx9uX7Z6mirVyAUjO4xOWMrKEBcJ9+BI1imAhSDI2SKFNPZ8Q8Bsd7Ta9oIWPjE7hfsFbdOtOXNDFRlRTL6pNCZ6sNYJb29tXrb5+tsCwn6P3Lv25g+CXVMvj/q+N1mcux2BOUnTpfmxAs3vndaxGchotsKRAEROTsul1UYQ53ecGdR4eEBa4iEhTdVlvYEJAiXbaOevbyxYdEy5b2Ag/+to7ju88/L7/90StDFqjqV+bYccbm0kTgn4SMq06vzgih/WHGPZluBS1COVG7qCFDeff81av3S3n16uXLRPeQfFnIK1UJD7GAlr1OPHWCZRPIT+HHJaRfgfeyxCB4HfhtGkVwDyYFoznh7jUDobWemYn9EpgRte3u4q0y5TWXtKE4r188f3mhJWASDgzmbZesi+cfLknABpBf+Of0u9880KbURTERQCihS+HHDvrjaxSamIuFmSmxYqwCk/DqQ0pQVma8QrE0BPVzMOq3FxZqm9I31MaiFgPFea1+cQnk559AfnD57/Dl528+/eqNJHETi+BkBLCoOjuIKAMB0sKupR7MHGbcYML4v19/e2X4G7xk9cwyLgJ9fKuBSQGYNJ20ixBqXsLNWAH5iPHQEECWPv/3N79h4mSkUZwYoEsH1AAcgvGur9odb1CUwrSWzdhVZF8PDRsYtvKv9+809MapV1MuwLJKf12630+/y6Q0/cMncFlexzSMlJBw98CDGK+0hkvfcerGTd0DolBpZlug4RDZ12iu+va1kg/qA2TTWFbh4wUEQnRmlq1yLfTha3HkJ1Wq+gWe+KMNFpLURBWpxHIKAFEcyykfUHFTRwcxS2E2DikUkGXOARQFso63by8uzkpnmlY6u4AIiKkKOoLlvK2opdKyUtHG/BHj/zqQTwwN+3dwvYEzZ2QVxoUBbuvAVHswRp53soX4s9Cm2QpQMCM4QBjRxVl6Y4vFNN9VGa6luK11BsmjCupXFfDZC/RmSH91DUjjymcJ8VGKH8DSsSB9WbYCINiMAok86FV7zrd0pdBalLEjlPB/Q66kGIqlNkFjgpGkf6r6YCefIcxYSfB4B2nkJntUfAvmULPXZuTz59+/+fSD+O4PCHeu0qwlaQdGUoV8FvLeYG6SLVyR92aFbHVaiCNFZbaatiycaKs90apIhMWV9GeWKkiU0F0vg/rKnX148Qopyneffvvttx8//fTxZ2BZ3338H+CIZjoXCgfjc8/hVM4DJ2hsL/jQ2SQTDEysKklNMXVBaTVFWz5jW8nXZd1B0WHbOrt49+Lb687ub//616+4+F/2//jxxx9/+6PsgfYsC7uJjfCONzLr4K6COtvenyejWsZVZY7lIGUcy/GWosF0Mhn2UIaTybQSRVFcSs5BSCcNSQ2o2btX4NKuZJCv/+60veSf58H/U8mNNIFSxUR+6HjzcdkJRhJp/bZhNUthNhyoWmgXdowF3qHaQb/80YqzUdnq1xbD6SBW3gk/1KEIoGVYuNgIQ6//7gXjRmM+Pu10OqN5XeIaoVpcgy8cOMm8jd0ao4Pbm6hqcdaVDABiVybnrTCUgjRjGGdxs7OUmi4uURrgZmTYPJ/GtpUSR+0MeyR08GbPP1yqGQCBsMGwhn8osdxNeUqrktYZr+y0/bok12nJugwHWZdjKW8CkxBAhUCXwwpaem3jGuBgBAGCASQDdARIUrgY4EEP4J0xgmAWA7S/BPafMM7/9bwDhpwKojiMfRx4HvDdIIDPoHD4becYe5zcW/s0KsPsyxh0pUQGmaGPmtyZB4T93ixSFdSk6o35CnozLPE999pjtAsM4tVTr132sCLtgMV4TuCP5sfVa8nHVSFGaNdyVVSMHgKp3AUEBwlqNozSorby2Jjf23Z8EQeBf4hNAIxXAUHnoNrtdqv1+nG9Wu1K7Ai6ad1q8/qiFzfznEJARB9dUrw8xmTLeYouMQz8R83wfBbj2hCmJsi4UM3sctJsJgyg6EHDBBMHPXOBUhmu2nEo7tySTwpRJdemBi4MPC7DOl/CuLNmaRZkfzGplPSkXq+KW//pOL7kzOj6YNT3Wvd3m9rEzFPmcllhgsqijGS3Y1OJ4RosbPWHFTsJpMBmyk55XiBs7gTHt7umbWJOtFpGynhFDNpEWhLLFMcOQBjDZUIuXAJg0JtZOCUQtcFAOnQbJ7xdwqhE8radG2jAdo2S7OfY4lok6NmsUvo/UK4T3/GO76UeplGzpvf5ww0RPSwtVGBu7nFyqmG41JWgaL6HfZbB/XosBZnZ+U9NIk3FDVviHjgoeFwkAVwc+tgzegu5vU1YqFV2T0W2jZNIXFK0JjTPSbbMleOg3blfSzopzLTerpa+3QAY7WEoiVp5egGB5srqQfd+LSxGX4+bO1r6LR7JJWEJ61WLewxhJdilSFTv0j3+WMys2a5/aNLtmmMWpshpK19+i/lNAregX9J3DiK34GDUDVUF8fxL7dS8VZjLZna083liW4EAn6fEnWCqHuc7wuWeIty+bdVurHTdJNtxqAxI7RSzhg979koiQkZ6JUO3w204TC6nSP/ixzjKj050vZYliNz8rMIB2tVX/U6TR9AteOVBBgJ/Mw6a4EDONFXrH7fspoSknFFDsEuWDswRve7qocpIkoemUIs8Qnllsv2ihMiBDbw3X/P0CkeBFVwZ42pOxLZOckJq+frITSyRiMuH9HLzEVPMjapP5tU25kth5tDSBzd0cGaBcYmjIODWnKvy4tbkndLq/PT0zYG8LHjKRqNxfEmu8OHhckjMrTdW0t0aI4yabmvAa3IQ+HUcKDDHai97Tdx0/5jojrAe4rXLyy0IgtfLba98mX1gul5NW69Bm+ae57STAkT9Zm/IXNKKNGuRK59amvnaVftYvTqrhDelqmo9IBiPR47XoCkOMcdKycHqEgpIuhUeTOkkCLCWEgR+UL9ZXw0mZppWydVJfg0H7mcfopXY05ssj1W9clBlTFZHKRDVQwp3fLQOBLvlkt/nBMt1MIsNKbdtOyJgILbWz7NN7DoOFFFRRZ7eDRUPfgw3vw72wXi4HCoMPPBx4T81k2rQ9qobfypHkKFsyXzBKtyFbWnDwv07nZQ7uSHUiyaecWYVz8k1rRVdsJDgFOu6ac8hJyeOMx+3gwOWMBszUa11c7gNCCSktZKlz4xMu7U3xrx0i9d+i7kLVUGMW9fO/wMbcbwymK5/nC68cu577W6j7I1l6rIVEGNXIIK1SroWtViWLGhj0ObW1AQMFc+p0ez42nEihHVPA8xlnaXXItW24+Pg/cPEwIWyEeXyIBAatwIx1BY1y9LOM2WUG8O+reZjuHKAnEsd8LIhzOC8ejzvgL8dpR3sY8c5OpkHbaeeNmMkqpXatXkNyPq9oYLiKoDVo9caOW6FsdYJelvJBwZPkm3UWnSl3552wdDBE80dryMpcIKCBAhg3WXPG5sE6ZqpZkQNm6UWeAkExsDWVjoNPCnD1iau2L2HfPMc9LsqV4z04zO0k0roCuMy3vLGUfWQSQBSHokT32+YeDqQDwKmI+nI96tMea3D7uGh5PA8to/KUdlpQNh2674/NpdzgrssMG2wBlkiSGrZKxR3mBZ3aS1pjI2aVFyeNsAbXrkzHp/CTT8ozNvOnGLrUihl6DvtgwJ2M+Due8c/6hx15hSs6dBIZwTP1Tsue53L1yDuOR4NHoUZpyP1UDsVRA1G3Jpq0LAQyUqx+QGMrVyGTwfE/AcAkUeOdyzBcuZe+6jgAw0BY2+3PWQxYwDiITNPgRDj2Gl3VvGC0IWq2gCF2HVG1gOGoqG7uDpwwiW1/KHVxKqll/HufHQEN7vLOD8ej+vdN2/mXSwRdsdv5vIfb8ZV3v3H+I2SA/5mPMZNCuwEfhP7OqrjNydJQQCX8zCv1qMMBy2tB4wtMfAmEeYiaSTQe8RNtQss3VRzikd68oLJXbggHsMI6scpGrf6Lpl1ynHXDsE1PhNXSrBnKDVTSszWQHmT5u4BfSPwZcABM94vJd0Ds2XHN6RTHASXFAl+hk8cYwUYADOwMs9w1w8XwhXUJQI7GbH1F9d2edoAkU4AmIdu2eDfM+jV+tjVg11vgTBqsVXEhcK4KYlr5Du75lKICCe4AceuhDv7q6s8JNOKgWBmP9KS/r9h7jORVkJprYJNFvZs94PhrvGpTJV2oIEiHKRNAlH/5p0V2UVOS7p+putDufOpJYmLylOUZkLOLNUwZBWH4R1L/XeIwHMZhazFOrZOxYss05H7TRQharmLOD1lPVrIPPUBARyG1gZ4LUgIa3TXA9X2gQO4CjjaZpS8lwXE+QXNo2Bmv1JSB7Zbk9Dd9VzZfcBIRYhJ0o+GhLgm8VBoChR59783wNpcIpsDtSFAt0rndOd3itkjDsyqa5Wz9ERpu7Jomdn6cglzhYnvFZH2sk1b5s7n9O0TBlYkXLkoYdcZtgpq8ayf7dq00J9GqFHYWBj11QLMTrdir9ORCDjiGZJI1U8Ho+lJiW0ZVLCtRUmh3giGEBkuolULXtzLcDbF/mEgy3PN2izdhKFUbNCrAeGjxtadjxTPaGrVegN1KoaCEk9adPf1sN1hZJg5FxtiZH+mmk5VL51ul6LKpBYi77kBBVw1PJ9UIrXikrzrSnHYBLvfuX6169jMlex44QLOS3NWSrbDJptegTDFg+F5SyZCsB6H/5u14aBk28lvpSdrT7KxnN1hpEXfLDpIhWs2JxU1Pn3ZWKslO3grs0TwXYbUluulHuIvxINFaGZa0tsNxxJGVgJDDODoFN80ybb0dNO42iC3HHOqdEnjI8ZQdA/qbZNckmnxfUcY9F4w1sQAw8cQjdqjLZuFN7eYqV29ACmeNK+XLPch952NDWG0IGuTQaQ06wYg6kk9jma9PgVfYH6BAzP3MB0FVcuBJFC2+ufDQWxfWsxyfmw7mg5rzZCYkFMaO4a/LLKX6dgUInmz1lNvJRbhG4wNpsNFLWSFfRw3tl32DgOFCeMyBU1e5Iu/L9ISx94uKArAhJO9LrjDAlch1RsRfekF7v1PxyPJVwLj6Y3en+RJnuRJ9iL7T80fR75EkeEx5AsUfR5FnnD8ueQrgfF14bjH3/0/lk5u9D4FEIEAAAAASUVORK5CYII=", 'JPEG', 20, 0, 25, 25)
      doc.setFontSize(16);
      doc.setFont("helvetica");
      doc.setTextColor(255, 0, 0);
      doc.text("Armes et munitions (Code: " + this.formId + ")", 105, 15, null, null, "center");
      doc.setTextColor(0, 2, 3);
      let i = 35;
      Columns.forEach((element) => {
        doc.text(element["header"], 10, i, { align: "left", });
        i = i + 10;
        doc.setTextColor(255, 0, 0);
        doc.text(documents[0][element["key"]], 10, i, { align: "left", });
        doc.setTextColor(0, 2, 3);
        if (i >= pageHeight) {
          doc.addPage();
          i = 15
        } else {
          i = i + 10;
        }
      });
      doc.setTextColor(51, 10, 199);
      doc.text("Ce document a été généré par le système GES-UPRA au " + dateString, 105, pageHeight - 5, { align: "center", });
      var pdfBase64 = doc.output('datauristring');

      let config = {
        headers: {
          'Content-Type': 'application/json',
          "Authorization": "key=AAAALeem-1k:APA91bFi6XX1XOe2gz-VGRBEKI00LfWbXS8TpYRQKzKzc9L3mVKJgZwXWJuNZetn5F316V1ePT_qwFyrR-6q7nwVGs7Hp649JGlEb-wUdpRfDyfvrEcaUxFlsGEjjMXjZY6ap2pQwY-Q"
        }
      };
      let body = {
        pdf: pdfBase64,
        formId: this.formId,
        email: this.email,
      };
      await AXIOS.post("https://thawing-badlands-05581.herokuapp.com/sendMail", body, config);
      this.loading = false;
      this.snack = true;
      this.snackColor = "success";
      this.snackText = "Mail envoyé avec succès.";
      this.dialogMail = false;
    },
    //send mail to user finish//

    async deleteItem(item) {
      this.loading = true;
      if (confirm("Etes vous sûr(e) de vouloir supprimer ce formulaire?")) {
        this.loading = true;
        try {
          await this.removegestionSecurite(item);
          this.loading = false;
          this.snack = true;
          this.snackColor = "success";
          this.snackText = "Formulaire supprimé avec succès.";
        } catch (e) {
          this.loading = false;
          this.snack = true;
          this.snackColor = "error";
          this.snackText = "Formulaire non supprimé";
          console.error(e);
        }
      } else {
        this.loading = false;
      }
    },

    async exportFormToPDF(idForm) {
      let Columns = [
        {
          header: "Nom et prénoms de l'agent",
          key: "userName",
        },
        {
          header: "Intitulé",
          key: "intitulePassation",
        }, { header: "Statut", key: "status" },
        { header: "Adresse email de l'agent", key: "userEmail" },
        { header: "Date et heure d'envoi", key: "dateEnvoi" },

        {
          header: "Vacation",
          key: "vacation",
        },
        {
          header: "Agent entrant",
          key: "nomEtPrenomAgentEntrant",
        },
        {
          header: "Agent sortant",
          key: "nomEtPrenomAgentSortant",
        },
        { header: "Etat (REVOLVER 9mm RJ131910645)", key: "RJ131910645etat" },
        {
          header: "Anomalies (REVOLVER 9mm RJ131910645)",
          key: "RJ131910645anomalies",
        },
        {
          header: "Date de sortie (REVOLVER 9mm RJ131910645)",
          key: "RJ131910645dateSortie",
        },
        {
          header: "Date de retour (REVOLVER 9mm RJ131910645)",
          key: "RJ131910645dateRetour",
        },
        {
          header: "Observations (REVOLVER 9mm RJ131910645)",
          key: "RJ131910645observations",
        },

        { header: "Etat (REVOLVER 9mm RJ120205375)", key: "RJ120205375etat" },
        {
          header: "Anomalies (REVOLVER 9mm RJ120205375)",
          key: "RJ120205375anomalies",
        },
        {
          header: "Date de sortie (REVOLVER 9mm RJ120205375)",
          key: "RJ120205375dateSortie",
        },
        {
          header: "Date de retour (REVOLVER 9mm RJ120205375)",
          key: "RJ120205375dateRetour",
        },
        {
          header: "Observations (REVOLVER 9mm RJ120205375)",
          key: "RJ120205375observations",
        },

        { header: "Etat (REVOLVER 6mm RL130410466)", key: "RJ120205375etat" },
        {
          header: "Anomalies (REVOLVER 6mm RL130410466)",
          key: "RL130410466anomalies",
        },
        {
          header: "Date de sortie (REVOLVER 6mm RL130410466)",
          key: "RL130410466dateSortie",
        },
        {
          header: "Date de retour (REVOLVER 6mm RL130410466)",
          key: "RL130410466dateRetour",
        },
        {
          header: "Observations (REVOLVER 6mm RL130410466)",
          key: "RL130410466observations",
        },

        {
          header: "Munitions reçues (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOrecues",
        },
        {
          header: "Munitions utilisées (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOutilisees",
        },
        {
          header: "Munitions restantes (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOrestantes",
        },
        {
          header: "Munitions usées (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOusees",
        },
        {
          header: "Munitions détruites (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOdetruites",
        },

        {
          header: "Observations (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOobservations",
        },

        {
          header: "Munitions reçues (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWrecues",
        },
        {
          header: "Munitions utilisées (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWutilisees",
        },
        {
          header: "Munitions restantes (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWrestantes",
        },
        {
          header: "Munitions usées (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWusees",
        },
        {
          header: "Munitions détruites (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWdetruites",
        },
        // {
        //   header: "Date de sortie (Cartouches à blancs 9mm TG6768AW)",
        //   key: "TG6768AWdateSortie",
        // },
        // {
        //   header: "Date de retour (Cartouches à blancs 9mm TG6768AW)",
        //   key: "TG6768AWdateRetour",
        // },
        {
          header: "Observations (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWobservations",
        },

        {
          header: "Munitions reçues (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOrecues6mm",
        },
        {
          header: "Munitions utilisées (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOutilisees6mm",
        },
        {
          header: "Munitions restantes (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOrestantes6mm",
        },
        {
          header: "Munitions usées (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOusees6mm",
        },
        {
          header: "Munitions détruites (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOdetruites6mm",
        },
        // {
        //   header: "Date de sortie (Cartouches à blancs 6mm TG3529AO)",
        //   key: "TG3529AOdateSortie6mm",
        // },
        // {
        //   header: "Date de retour (Cartouches à blancs 6mm TG3529AO)",
        //   key: "TG3529AOdateRetour6mm",
        // },
        {
          header: "Observations (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOobservations6mm",
        },

        {
          header: "Munitions reçues (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWrecues6mm",
        },
        {
          header: "Munitions utilisées (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWutilisees6mm",
        },
        {
          header: "Munitions restantes (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWrestantes6mm",
        },
        {
          header: "Munitions usées (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWusees6mm",
        },
        {
          header: "Munitions détruites (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWdetruites6mm",
        },
        // {
        //   header: "Date de sortie (Cartouches à blancs 6mm TG3529AO)",
        //   key: "TG6768AWdateSortie6mm",
        // },
        // {
        //   header: "Date de retour (Cartouches à blancs 6mm TG3529AO)",
        //   key: "TG6768AWdateRetour6mm",
        // },
        {
          header: "Observations (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWobservations6mm",
        },

        {
          header: "Munitions reçues (Fusées détonnantes TG3529AO)",
          key: "TG3529AOrecuesDetonnants",
        },
        {
          header: "Munitions utilisées (Fusées détonnantes TG3529AO)",
          key: "TG3529AOutiliseesDetonnants",
        },
        {
          header: "Munitions restantes (Fusées détonnantes TG3529AO)",
          key: "TG3529AOrestantesDetonnants",
        },
        {
          header: "Munitions usées (Fusées détonnantes TG3529AO)",
          key: "TG3529AOuseesDetonnants",
        },
        {
          header: "Munitions détruites (Fusées détonnantes TG3529AO)",
          key: "TG3529AOdetruitesDetonnants",
        },
        // {
        //   header: "Date de sortie (Fusées détonnantes TG3529AO)",
        //   key: "TG3529AOdateSortieDetonnants",
        // },
        // {
        //   header: "Date de retour (Fusées détonnantes TG3529AO)",
        //   key: "TG3529AOdateRetourDetonnants",
        // },
        {
          header: "Observations (Fusées détonnantes TG3529AO)",
          key: "TG3529AOobservationsDetonnants",
        },

        {
          header: "Munitions reçues (Fusées détonnantes TG6768AW)",
          key: "TG6768AWrecuesDetonnants",
        },
        {
          header: "Munitions utilisées (Fusées détonnantes TG6768AW)",
          key: "TG6768AWutiliseesDetonnants",
        },
        {
          header: "Munitions restantes (Fusées détonnantes TG6768AW)",
          key: "TG6768AWrestantesDetonnants",
        },
        {
          header: "Munitions usées (Fusées détonnantes TG6768AW)",
          key: "TG6768AWuseesDetonnants",
        },
        {
          header: "Munitions détruites (Fusées détonnantes TG6768AW)",
          key: "TG6768AWdetruitesDetonnants",
        },
        // {
        //   header: "Date de sortie (Fusées détonnantes TG6768AW)",
        //   key: "TG6768AWdateSortieDetonnants",
        // },
        // {
        //   header: "Date de retour (Fusées détonnantes TG6768AW)",
        //   key: "TG6768AWdateRetourDetonnants",
        // },

        {
          header: "Munitions reçues (Fusées crépitantes TG3529AO)",
          key: "TG3529AOrecuesCrepitants",
        },
        {
          header: "Munitions utilisées (Fusées crépitantes TG3529AO)",
          key: "TG3529AOutiliseesCrepitants",
        },
        {
          header: "Munitions restantes (Fusées crépitantes TG3529AO)",
          key: "TG3529AOrestantesCrepitants",
        },
        {
          header: "Munitions usées (Fusées crépitantes TG3529AO)",
          key: "TG3529AOuseesCrepitants",
        },
        {
          header: "Munitions détruites (Fusées crépitantes TG3529AO)",
          key: "TG3529AOdetruitesCrepitants",
        },
        // {
        //   header: "Date de sortie (Fusées crépitantes TG3529AO)",
        //   key: "TG3529AOdateSortieCrepitants",
        // },
        // {
        //   header: "Date de retour (Fusées crépitantes TG3529AO)",
        //   key: "TG3529AOdateRetourCrepitants",
        // },
        {
          header: "Observations (Fusées crépitantes TG3529AO)",
          key: "TG3529AOobservationsCrepitants",
        },

        {
          header: "Munitions reçues (Fusées crépitantes TG6768AW)",
          key: "TG6768AWrecuesCrepitants",
        },
        {
          header: "Munitions utilisées (Fusées crépitantes TG6768AW)",
          key: "TG6768AWutiliseesCrepitants",
        },
        {
          header: "Munitions restantes (Fusées crépitantes TG6768AW)",
          key: "TG6768AWrestantesCrepitants",
        },
        {
          header: "Munitions usées (Fusées crépitantes TG6768AW)",
          key: "TG6768AWuseesCrepitants",
        },
        {
          header: "Munitions détruites (Fusées crépitantes TG6768AW)",
          key: "TG6768AWdetruitesCrepitants",
        },
        // {
        //   header: "Date de sortie (Fusées crépitantes TG6768AW)",
        //   key: "TG6768AWdateSortieCrepitants",
        // },
        // {
        //   header: "Date de retour (Fusées crépitantes TG6768AW)",
        //   key: "TG6768AWdateRetourCrepitants",
        // },
        {
          header: "Observations (Fusées crépitantes TG6768AW)",
          key: "TG6768AWobservationsCrepitants",
        },

        {
          header:
            "Munitions reçues (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOrecuesAutres",
        },
        {
          header:
            "Munitions utilisées (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOutiliseesAutres",
        },
        {
          header:
            "Munitions restantes (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOrestantesAutres",
        },
        {
          header:
            "Munitions usées (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOuseesAutres",
        },
        {
          header:
            "Munitions détruites (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOdetruitesAutres",
        },
        // {
        //   header: "Date de sortie (Autres munitions d'effarouchement TG3529AO)",
        //   key: "TG3529AOdateSortieAutres",
        // },
        // {
        //   header: "Date de retour (Autres munitions d'effarouchement TG3529AO)",
        //   key: "TG3529AOdateRetourAutres",
        // },
        {
          header: "Observations (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOobservationsAutres",
        },

        {
          header:
            "Munitions reçues (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWrecuesAutres",
        },
        {
          header:
            "Munitions utilisées (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWutiliseesAutres",
        },
        {
          header:
            "Munitions restantes (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWrestantesAutres",
        },
        {
          header:
            "Munitions usées (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWuseesAutres",
        },
        {
          header:
            "Munitions détruites (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWdetruitesAutres",
        },
        // {
        //   header: "Date de sortie (Autres munitions d'effarouchement TG6768AW)",
        //   key: "TG6768AWdateSortieAutres",
        // },
        // {
        //   header: "Date de retour (Autres munitions d'effarouchement TG6768AW)",
        //   key: "TG6768AWdateRetourAutres",
        // },
        {
          header: "Observations (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWobservationsAutres",
        },

        // { header: "Commentaires de l'administrateur", key: "commentaireAdmin" },

      ];
      this.loading = true;
      var m = new Date();
      var dateString =
        ("0" + m.getUTCDate()).slice(-2) + "-" +
        ("0" + (m.getUTCMonth() + 1)).slice(-2) + "-" +
        m.getUTCFullYear() + " " +
        ("0" + m.getUTCHours()).slice(-2) + ":" +
        ("0" + m.getUTCMinutes()).slice(-2);
      const snapshot = await firestore().collection("armesMunitions").where("idForm", "==", idForm).get();
      const documents = snapshot.docs.map((doc) => doc.data());
      const doc = new jsPDF();
      let pageHeight = doc.internal.pageSize.height;
      doc.addImage("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAC5CAMAAABa+IDIAAABIFBMVEX////3/PYAjzb8/vv1/fUCkDn5+/b39AD///34/PX3/PgAkTbXIxYAjjoAfL35+/j68wAAer3u9/ICjDsKlEAhisAAe7Y1pmEMf73M5+ux3MGy2OOGwNrh8ebO6djV7Nwem08Ae8OVyNs0lcYZmkvX6+rj8vGBx5274Mkpj8Sm0eFBrGt5w5Z9vNM8mcmDxSZXqM9Enca+3hlmvIkPljRwviZatn6d1LJKrXFtstKVzR7a6QiSz6pgqsYinjJCqy5Wsyut1hbV5wzepZ/UJh349DveHRQtdTHRNSjoycGgO0HeVUrZRDnbhnowZpdySWHs29TadGpRXoJdhTD1zQw1lJVutcjNU0LhixMAi16gzkzQ5kPbZVdEh7VlrGwAgYkp1n3kAAAbJklEQVR4nO1dC3vaOLNGluxa8tpeCwzmYjDBBBIIJSUl0NL0tvud7r273/Wc71z+/784M7IhkIQExzTZp08mbRJIYvRac3lnNBKFwp9IzMcewH7ENL8OIE84/lxifh1AzCccfyr5mnA89hj2IV8Rjscewn7kK4HxJE/yJE/yJE/yJE/ysEIpRT4IpBC+eezBZBNmuIQxQgwhqGBhs7ZY9Hq9xXmtGboUhRGDMEM89jjvFByoIVvN8+EsKtkaiG2BaDZIXJn2as2WpNQgjz3Ou4QWaL83rcSWpum2peuagqDDQ03XbcCklaLBZNF87HFuFcYEB4Wh/Wlc0nEeEIEGSKx0PgAGfIVn4Ae6XoqHLdMlhJE/m44ZhivC/qSk7j3CUOOOo6gym0565yiLxXAyG1SiuITQNDvqNaUQ7LFHfkVooT+pwG0HZdJ0+LC1ymRx3gd7gB+a6LzwAzyYRPsfzmLEog16rcce+KWAC2LCqFVQo2xdobCiSU1KsiWFxSelbC0GNuheadoSRIg/g+0zl4W1ip2qlK7H0bBZMF3h3vZHJiG0IM8HccnWp6Bht/7yAwmVi4qNRoE2bg96fWK6rkHusmJeIMI0W+cTgDKrPW6wJBy8Dq1FGC3Qfq3ipCWzKokMF7GmzUJwYe5jeTBGXKM11c/QvnVLj4eS3qFRN19ELCJLX8jHsxSDhr0S6hNqVWURmoKAZL0KkBmT1AZ2dE4fZUbACGgTtEpXISOuSUFzXE3IfsWeScofHgsTsmdBnAbr0EsTQt1ceiGYy3tx3CcPHx/N5gxUykIc02YBqG4+BaeCmK2JNpR55jW7wKvWYsVELDvqy3tdQn0SQPmXTBgCSz+qtAyY3QebF0P2EkJraVOZgy4xLqtdZqweEz6Nm8RlfB+D3EXkRFcRUI/OTXGvl6XJHxF52l3zukS4i2jhsofRL0OEAzRzYOizljDu/oNrAoyfwD8I7+aJL8nGjaCtwRCcOLvPdTMKCytakltM7hmLAQRRBJ7I4OgKEGbIwVCQBzATs1WBuQDriBdm9vCnhArelRgy6NzrXAECEMlkIr94lCeiGSGv0q24f+/gBYoz7zLGSNdvdyS7cvOJS86n0iDsi2IRIVBdjB5R6N7bJDmtB11CuGw4AIRcu45rLIZ30uecElaQ5up6JczBjAjz/SpEEBk4ztHhNUMTxKCLofyCZkJcCfaBVLcS3huG4NxsOEGVE3PueI7fvcnQqFvrZc4Idhcip4gDUtkctmgIcdhxfAAiPSfw/OqNjlaI7KnN7kIhnqOdw3zkeBHBjwOYEcEb5WDeDuri5sn9YukJF+Y52jnMR0sUchgIYSOv3K4T2fFGXc873ubDc9LQ7QMQzZLSK6uVi0EwXvectncg4MsBDcon8oGpu5ADHSuHpT7NRR8I7zgj35uTuRNIcwwR8cEoIoiAfHQI7kovWr170atLoTAT9bHTEb4zNvFB9yGBEEL7qqRrzfK+LB07R926U663nSpnPHDmD1kLYiKMVeUqknkDbtcvjzkDv1U+YkBDIJbIB0RCyETDqk/czOcUCTfrgVcnfOy0nRNOBKsG3onJH4C0J2I0S6o4vTALuXyMAVPQDrjgAMerC4NSeQrB/eFq8mSGKzdWRd6fKSbX4bLjjCG6wxcfklyTGnWwkgeqAhFinqvKj97K+4KMHTpenQMrPG2PkMCbnL+BuaHkIVwXc2Ws41LTgvKc2TQjx57DOIGw3h5Tlc8K5jte1RAPgIS5Q7UGVZG5X00UICcEHAJSqkYChJFqAA6ZPwAQEUZo6aXze1R2rwgzjxxwvgSclXNMVe5EuDjwyqdMumuWgv6ME67WuXO+5JqQBS4c2JU9kDhhBk6DGESAiVeX4yZ87pVHlK/NNyOcG9ygpnE1Ec4jMlLLUffP0S+Fccc55oKQuuN1l3EQkt5x2zmVZLUkQWX1eD7yfX/UqO6tiCrMBS7jWLN90GohHadOBBHHyBiXzxIhx453Kg21dGTQ6nwESbDn4H/v9JjzfZS5DOHChJxpdsvdg7a6IXhfmBAA4qyXjDk7dTxfokbx6giCZdvxx/P5HDIXJxhzvof83aAYQyxrKvdhdkbYVkBQtdaBEEbHngqRVdAyLzg9ltiIY1LZ8D3Quj2UhpjEoK6VaqKwB2VlzEMbEaLuON216wlQn7nndeonMBt+owrsizDwWwY3D8eBM95D/i5aMZKTaD8UlaHXAmMXwBXrmzeGkAPPCRyv3JCMq0U8tCX4xMbgIPIDcc/V8kFvP1SbFjreGNeuqz7EkY0fge86Djyn04X4IcjyA35V8iMwn9wvTQY6ZoZ7qs0Ic+z4EAjJ4ZEzv7JiCACAEyMQtj4hYP9dz5sX8ppoaIPz1Sb58vSVEAONQ8AAR86pca1rC+sSRxx4F1F9HfDB0FIYmE9uDtNTjUnNPS0dA1sMvLlJBJ0Hfte4MjbKDXDLp0gq0wkBSLIrJRCak1y9ahCHInS+FZmbZaUXZHLsBVIwo+4F9WvaQtB3OSdyNSFYBCuPGTl1OrmUm5JQLekM8wx+QwQ/LoPfYpyD3t8UHeTIc6rGckKIUW0HHuMHTlDNA0QYC1U7qeW4xoYYgnU77VEoOB0DSbmu9pBCBmUf5iN1W5yeeifCkJ7XyAOEUKw56FHLEHTF4QUBcnrPq1KD0IbjHcMFug4S+WvX4bTuYTkinRLGTckNVoA8LA9LMcIB5uoDTAw56gOkEhR5ncEoveeFOR/BXDDJT50AE45rvwBW5B+yZSQB9wvzwueOn8drGa0I212HUoZrIkEIce/ZLEYgbXc6cEvgzjeoedUbmiapB+WGuzQSmBSDSXmFZO70QuApCoKaBRo2+9j9Y2tRVMJeS8tWLXKluFKZTXqLWjNkQOwg6ca2rQxASMNz5oQfdpzOIb8yI9iyzTptoImJzwIFqB7MR50jxzksZCPzarle1npT7AdNmkZ11chka2m3H/bLaZZdKkWVWa9PCtj3mmkLnhyVPfC9B23v+MpKIeKgYEW4xKhwGPWRD5weKJg34ltWUrYIEefTyMYoiGvQSeexrl0VPWl9wO7kSq+ZMcww6XtBlXPfOdp0XAoHOC7wAy4C4d0Rknp/dBpApjW/On13vIpQ67ZqFnAdAfvKsA1ZTwQrp/DD5ElbTY6mxdNFP4RRCHRnd983iA4KSb3snECUX2FROMC6TeAv4FoEO0AWOa/ij+rjIKhjrrgzEFdUknuu+hSxjcm+lGIRP9nKYFRjbNIiBKDiaLYIC4BF3G0vnGN90a9ySHCrYMsbOAAIbXg+TTKU4OAwWYPjEjLHQ5ahSkxpRU+HVwQTPzu7ePvu5fNX718k8v7V8+fv3p6daar7IdU51TiOi3LDJji0O2cEJk4cgMZIYLvArJa/n8wHiFt1HCYg+21DzgiunyENA/54MOIZdJiDatlF/ewtjP/V+w/Pvt2Q1cPXH94DoLeQzIOd4JK1WrfW7HjWq7WkiX4VIg69cXaIwLgIc+KDDdeX1BEnRPF2Ig5hpuQp5rgwL1T5EQDP6WE3A3XkpHLx7tWLD6+fqUE/U/It/ls+wB8kgJ69/vDi+buSVVRWpSXtphr458l5iBRAufIbBeh5I2g7Y9/rSGM1IQkORZGP521vLK8oUqZN1pJ9n4w/+fRsm3yb/AZi+vD8Qk+1TFkWapkdTWoh8vGb6wZg4lUfmDykJwd8hUMoJELII6fjlEf59jIw8v3GaJMZWFOqbzd/lvz4wyswnCLuFAG70tIdIwDm48fPnyUMkeHdxkCbDg3cz9jz6iZwR0/is6lipTPS8TxcJc1VBSLi+/RGpwgSFfqAhg7/P4DOrezlEg1azYtX7y6Kto5gEh9gW//xl+8+/fzT7x9/CEHT4YZjLVclhoQeOE7DhHkJPCwGXyqWmpGOh04tBwqcEfH95fhevHr+7iLWzrSirhWT2KEVtRI4sufvX6/PSmJEz56BlqFyqc0XCsg3qXz3z18+fpZIahkGGqMLEQLScSFHMOQlkLTcwEG1gmOesyhHCMzI6xfgky4wcBeLSltQ99Gci8k3+HxRuwA4L9QErWvZ6/cv316gdoFXBiDffbOSv3zz6Z+///Lx4w8/fP48bkN8I1wAr4VUgy81S02KcQJkzLzWK0mznUTA+H+9e3tR0oqoJeBZbS3d3bJJUbCTHAK7fnHx9uX7Z6mirVyAUjO4xOWMrKEBcJ9+BI1imAhSDI2SKFNPZ8Q8Bsd7Ta9oIWPjE7hfsFbdOtOXNDFRlRTL6pNCZ6sNYJb29tXrb5+tsCwn6P3Lv25g+CXVMvj/q+N1mcux2BOUnTpfmxAs3vndaxGchotsKRAEROTsul1UYQ53ecGdR4eEBa4iEhTdVlvYEJAiXbaOevbyxYdEy5b2Ag/+to7ju88/L7/90StDFqjqV+bYccbm0kTgn4SMq06vzgih/WHGPZluBS1COVG7qCFDeff81av3S3n16uXLRPeQfFnIK1UJD7GAlr1OPHWCZRPIT+HHJaRfgfeyxCB4HfhtGkVwDyYFoznh7jUDobWemYn9EpgRte3u4q0y5TWXtKE4r188f3mhJWASDgzmbZesi+cfLknABpBf+Of0u9880KbURTERQCihS+HHDvrjaxSamIuFmSmxYqwCk/DqQ0pQVma8QrE0BPVzMOq3FxZqm9I31MaiFgPFea1+cQnk559AfnD57/Dl528+/eqNJHETi+BkBLCoOjuIKAMB0sKupR7MHGbcYML4v19/e2X4G7xk9cwyLgJ9fKuBSQGYNJ20ixBqXsLNWAH5iPHQEECWPv/3N79h4mSkUZwYoEsH1AAcgvGur9odb1CUwrSWzdhVZF8PDRsYtvKv9+809MapV1MuwLJKf12630+/y6Q0/cMncFlexzSMlJBw98CDGK+0hkvfcerGTd0DolBpZlug4RDZ12iu+va1kg/qA2TTWFbh4wUEQnRmlq1yLfTha3HkJ1Wq+gWe+KMNFpLURBWpxHIKAFEcyykfUHFTRwcxS2E2DikUkGXOARQFso63by8uzkpnmlY6u4AIiKkKOoLlvK2opdKyUtHG/BHj/zqQTwwN+3dwvYEzZ2QVxoUBbuvAVHswRp53soX4s9Cm2QpQMCM4QBjRxVl6Y4vFNN9VGa6luK11BsmjCupXFfDZC/RmSH91DUjjymcJ8VGKH8DSsSB9WbYCINiMAok86FV7zrd0pdBalLEjlPB/Q66kGIqlNkFjgpGkf6r6YCefIcxYSfB4B2nkJntUfAvmULPXZuTz59+/+fSD+O4PCHeu0qwlaQdGUoV8FvLeYG6SLVyR92aFbHVaiCNFZbaatiycaKs90apIhMWV9GeWKkiU0F0vg/rKnX148Qopyneffvvttx8//fTxZ2BZ3338H+CIZjoXCgfjc8/hVM4DJ2hsL/jQ2SQTDEysKklNMXVBaTVFWz5jW8nXZd1B0WHbOrt49+Lb687ub//616+4+F/2//jxxx9/+6PsgfYsC7uJjfCONzLr4K6COtvenyejWsZVZY7lIGUcy/GWosF0Mhn2UIaTybQSRVFcSs5BSCcNSQ2o2btX4NKuZJCv/+60veSf58H/U8mNNIFSxUR+6HjzcdkJRhJp/bZhNUthNhyoWmgXdowF3qHaQb/80YqzUdnq1xbD6SBW3gk/1KEIoGVYuNgIQ6//7gXjRmM+Pu10OqN5XeIaoVpcgy8cOMm8jd0ao4Pbm6hqcdaVDABiVybnrTCUgjRjGGdxs7OUmi4uURrgZmTYPJ/GtpUSR+0MeyR08GbPP1yqGQCBsMGwhn8osdxNeUqrktYZr+y0/bok12nJugwHWZdjKW8CkxBAhUCXwwpaem3jGuBgBAGCASQDdARIUrgY4EEP4J0xgmAWA7S/BPafMM7/9bwDhpwKojiMfRx4HvDdIIDPoHD4becYe5zcW/s0KsPsyxh0pUQGmaGPmtyZB4T93ixSFdSk6o35CnozLPE999pjtAsM4tVTr132sCLtgMV4TuCP5sfVa8nHVSFGaNdyVVSMHgKp3AUEBwlqNozSorby2Jjf23Z8EQeBf4hNAIxXAUHnoNrtdqv1+nG9Wu1K7Ai6ad1q8/qiFzfznEJARB9dUrw8xmTLeYouMQz8R83wfBbj2hCmJsi4UM3sctJsJgyg6EHDBBMHPXOBUhmu2nEo7tySTwpRJdemBi4MPC7DOl/CuLNmaRZkfzGplPSkXq+KW//pOL7kzOj6YNT3Wvd3m9rEzFPmcllhgsqijGS3Y1OJ4RosbPWHFTsJpMBmyk55XiBs7gTHt7umbWJOtFpGynhFDNpEWhLLFMcOQBjDZUIuXAJg0JtZOCUQtcFAOnQbJ7xdwqhE8radG2jAdo2S7OfY4lok6NmsUvo/UK4T3/GO76UeplGzpvf5ww0RPSwtVGBu7nFyqmG41JWgaL6HfZbB/XosBZnZ+U9NIk3FDVviHjgoeFwkAVwc+tgzegu5vU1YqFV2T0W2jZNIXFK0JjTPSbbMleOg3blfSzopzLTerpa+3QAY7WEoiVp5egGB5srqQfd+LSxGX4+bO1r6LR7JJWEJ61WLewxhJdilSFTv0j3+WMys2a5/aNLtmmMWpshpK19+i/lNAregX9J3DiK34GDUDVUF8fxL7dS8VZjLZna083liW4EAn6fEnWCqHuc7wuWeIty+bdVurHTdJNtxqAxI7RSzhg979koiQkZ6JUO3w204TC6nSP/ixzjKj050vZYliNz8rMIB2tVX/U6TR9AteOVBBgJ/Mw6a4EDONFXrH7fspoSknFFDsEuWDswRve7qocpIkoemUIs8Qnllsv2ihMiBDbw3X/P0CkeBFVwZ42pOxLZOckJq+frITSyRiMuH9HLzEVPMjapP5tU25kth5tDSBzd0cGaBcYmjIODWnKvy4tbkndLq/PT0zYG8LHjKRqNxfEmu8OHhckjMrTdW0t0aI4yabmvAa3IQ+HUcKDDHai97Tdx0/5jojrAe4rXLyy0IgtfLba98mX1gul5NW69Bm+ae57STAkT9Zm/IXNKKNGuRK59amvnaVftYvTqrhDelqmo9IBiPR47XoCkOMcdKycHqEgpIuhUeTOkkCLCWEgR+UL9ZXw0mZppWydVJfg0H7mcfopXY05ssj1W9clBlTFZHKRDVQwp3fLQOBLvlkt/nBMt1MIsNKbdtOyJgILbWz7NN7DoOFFFRRZ7eDRUPfgw3vw72wXi4HCoMPPBx4T81k2rQ9qobfypHkKFsyXzBKtyFbWnDwv07nZQ7uSHUiyaecWYVz8k1rRVdsJDgFOu6ac8hJyeOMx+3gwOWMBszUa11c7gNCCSktZKlz4xMu7U3xrx0i9d+i7kLVUGMW9fO/wMbcbwymK5/nC68cu577W6j7I1l6rIVEGNXIIK1SroWtViWLGhj0ObW1AQMFc+p0ez42nEihHVPA8xlnaXXItW24+Pg/cPEwIWyEeXyIBAatwIx1BY1y9LOM2WUG8O+reZjuHKAnEsd8LIhzOC8ejzvgL8dpR3sY8c5OpkHbaeeNmMkqpXatXkNyPq9oYLiKoDVo9caOW6FsdYJelvJBwZPkm3UWnSl3552wdDBE80dryMpcIKCBAhg3WXPG5sE6ZqpZkQNm6UWeAkExsDWVjoNPCnD1iau2L2HfPMc9LsqV4z04zO0k0roCuMy3vLGUfWQSQBSHokT32+YeDqQDwKmI+nI96tMea3D7uGh5PA8to/KUdlpQNh2674/NpdzgrssMG2wBlkiSGrZKxR3mBZ3aS1pjI2aVFyeNsAbXrkzHp/CTT8ozNvOnGLrUihl6DvtgwJ2M+Due8c/6hx15hSs6dBIZwTP1Tsue53L1yDuOR4NHoUZpyP1UDsVRA1G3Jpq0LAQyUqx+QGMrVyGTwfE/AcAkUeOdyzBcuZe+6jgAw0BY2+3PWQxYwDiITNPgRDj2Gl3VvGC0IWq2gCF2HVG1gOGoqG7uDpwwiW1/KHVxKqll/HufHQEN7vLOD8ej+vdN2/mXSwRdsdv5vIfb8ZV3v3H+I2SA/5mPMZNCuwEfhP7OqrjNydJQQCX8zCv1qMMBy2tB4wtMfAmEeYiaSTQe8RNtQss3VRzikd68oLJXbggHsMI6scpGrf6Lpl1ynHXDsE1PhNXSrBnKDVTSszWQHmT5u4BfSPwZcABM94vJd0Ds2XHN6RTHASXFAl+hk8cYwUYADOwMs9w1w8XwhXUJQI7GbH1F9d2edoAkU4AmIdu2eDfM+jV+tjVg11vgTBqsVXEhcK4KYlr5Du75lKICCe4AceuhDv7q6s8JNOKgWBmP9KS/r9h7jORVkJprYJNFvZs94PhrvGpTJV2oIEiHKRNAlH/5p0V2UVOS7p+putDufOpJYmLylOUZkLOLNUwZBWH4R1L/XeIwHMZhazFOrZOxYss05H7TRQharmLOD1lPVrIPPUBARyG1gZ4LUgIa3TXA9X2gQO4CjjaZpS8lwXE+QXNo2Bmv1JSB7Zbk9Dd9VzZfcBIRYhJ0o+GhLgm8VBoChR59783wNpcIpsDtSFAt0rndOd3itkjDsyqa5Wz9ERpu7Jomdn6cglzhYnvFZH2sk1b5s7n9O0TBlYkXLkoYdcZtgpq8ayf7dq00J9GqFHYWBj11QLMTrdir9ORCDjiGZJI1U8Ho+lJiW0ZVLCtRUmh3giGEBkuolULXtzLcDbF/mEgy3PN2izdhKFUbNCrAeGjxtadjxTPaGrVegN1KoaCEk9adPf1sN1hZJg5FxtiZH+mmk5VL51ul6LKpBYi77kBBVw1PJ9UIrXikrzrSnHYBLvfuX6169jMlex44QLOS3NWSrbDJptegTDFg+F5SyZCsB6H/5u14aBk28lvpSdrT7KxnN1hpEXfLDpIhWs2JxU1Pn3ZWKslO3grs0TwXYbUluulHuIvxINFaGZa0tsNxxJGVgJDDODoFN80ybb0dNO42iC3HHOqdEnjI8ZQdA/qbZNckmnxfUcY9F4w1sQAw8cQjdqjLZuFN7eYqV29ACmeNK+XLPch952NDWG0IGuTQaQ06wYg6kk9jma9PgVfYH6BAzP3MB0FVcuBJFC2+ufDQWxfWsxyfmw7mg5rzZCYkFMaO4a/LLKX6dgUInmz1lNvJRbhG4wNpsNFLWSFfRw3tl32DgOFCeMyBU1e5Iu/L9ISx94uKArAhJO9LrjDAlch1RsRfekF7v1PxyPJVwLj6Y3en+RJnuRJ9iL7T80fR75EkeEx5AsUfR5FnnD8ueQrgfF14bjH3/0/lk5u9D4FEIEAAAAASUVORK5CYII=", 'JPEG', 20, 0, 25, 25)
      doc.setFontSize(16);
      doc.setFont("helvetica");
      doc.setTextColor(255, 0, 0);
      doc.text("Armes et munitions (Code: " + idForm + ")", 105, 15, null, null, "center");
      doc.setTextColor(0, 2, 3);
      let i = 35;
      Columns.forEach((element) => {
        doc.text(element["header"], 10, i, { align: "left", });
        i = i + 10;
        doc.setTextColor(255, 0, 0);
        doc.text(documents[0][element["key"]], 10, i, { align: "left", });
        doc.setTextColor(0, 2, 3);
        if (i >= pageHeight) {
          doc.addPage();
          i = 15
        } else {
          i = i + 10;
        }
      });
      doc.setTextColor(51, 10, 199);
      doc.text("Ce document a été généré par le système GES-UPRA au " + dateString, 105, pageHeight - 5, { align: "center", });
      doc.save("UPRA FORM (" + idForm + ").pdf");
      this.loading = false;
    },

    async printForm(idForm) {
      let Columns = [
        {
          header: "Nom et prénoms de l'agent",
          key: "userName",
        },
        {
          header: "Intitulé",
          key: "intitulePassation",
        }, { header: "Statut", key: "status" },
        { header: "Adresse email de l'agent", key: "userEmail" },
        { header: "Date et heure d'envoi", key: "dateEnvoi" },

        {
          header: "Vacation",
          key: "vacation",
        },
        {
          header: "Agent entrant",
          key: "nomEtPrenomAgentEntrant",
        },
        {
          header: "Agent sortant",
          key: "nomEtPrenomAgentSortant",
        },
        { header: "Etat (REVOLVER 9mm RJ131910645)", key: "RJ131910645etat" },
        {
          header: "Anomalies (REVOLVER 9mm RJ131910645)",
          key: "RJ131910645anomalies",
        },
        {
          header: "Date de sortie (REVOLVER 9mm RJ131910645)",
          key: "RJ131910645dateSortie",
        },
        {
          header: "Date de retour (REVOLVER 9mm RJ131910645)",
          key: "RJ131910645dateRetour",
        },
        {
          header: "Observations (REVOLVER 9mm RJ131910645)",
          key: "RJ131910645observations",
        },

        { header: "Etat (REVOLVER 9mm RJ120205375)", key: "RJ120205375etat" },
        {
          header: "Anomalies (REVOLVER 9mm RJ120205375)",
          key: "RJ120205375anomalies",
        },
        {
          header: "Date de sortie (REVOLVER 9mm RJ120205375)",
          key: "RJ120205375dateSortie",
        },
        {
          header: "Date de retour (REVOLVER 9mm RJ120205375)",
          key: "RJ120205375dateRetour",
        },
        {
          header: "Observations (REVOLVER 9mm RJ120205375)",
          key: "RJ120205375observations",
        },

        { header: "Etat (REVOLVER 6mm RL130410466)", key: "RJ120205375etat" },
        {
          header: "Anomalies (REVOLVER 6mm RL130410466)",
          key: "RL130410466anomalies",
        },
        {
          header: "Date de sortie (REVOLVER 6mm RL130410466)",
          key: "RL130410466dateSortie",
        },
        {
          header: "Date de retour (REVOLVER 6mm RL130410466)",
          key: "RL130410466dateRetour",
        },
        {
          header: "Observations (REVOLVER 6mm RL130410466)",
          key: "RL130410466observations",
        },

        {
          header: "Munitions reçues (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOrecues",
        },
        {
          header: "Munitions utilisées (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOutilisees",
        },
        {
          header: "Munitions restantes (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOrestantes",
        },
        {
          header: "Munitions usées (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOusees",
        },
        {
          header: "Munitions détruites (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOdetruites",
        },
        // {
        //   header: "Date de sortie (Cartouches à blancs 9mm TG3529AO)",
        //   key: "TG3529AOdateSortie",
        // },
        // {
        //   header: "Date de retour (Cartouches à blancs 9mm TG3529AO)",
        //   key: "TG3529AOdateRetour",
        // },
        {
          header: "Observations (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOobservations",
        },

        {
          header: "Munitions reçues (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWrecues",
        },
        {
          header: "Munitions utilisées (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWutilisees",
        },
        {
          header: "Munitions restantes (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWrestantes",
        },
        {
          header: "Munitions usées (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWusees",
        },
        {
          header: "Munitions détruites (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWdetruites",
        },
        // {
        //   header: "Date de sortie (Cartouches à blancs 9mm TG6768AW)",
        //   key: "TG6768AWdateSortie",
        // },
        // {
        //   header: "Date de retour (Cartouches à blancs 9mm TG6768AW)",
        //   key: "TG6768AWdateRetour",
        // },
        {
          header: "Observations (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWobservations",
        },

        {
          header: "Munitions reçues (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOrecues6mm",
        },
        {
          header: "Munitions utilisées (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOutilisees6mm",
        },
        {
          header: "Munitions restantes (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOrestantes6mm",
        },
        {
          header: "Munitions usées (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOusees6mm",
        },
        {
          header: "Munitions détruites (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOdetruites6mm",
        },
        // {
        //   header: "Date de sortie (Cartouches à blancs 6mm TG3529AO)",
        //   key: "TG3529AOdateSortie6mm",
        // },
        // {
        //   header: "Date de retour (Cartouches à blancs 6mm TG3529AO)",
        //   key: "TG3529AOdateRetour6mm",
        // },
        {
          header: "Observations (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOobservations6mm",
        },

        {
          header: "Munitions reçues (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWrecues6mm",
        },
        {
          header: "Munitions utilisées (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWutilisees6mm",
        },
        {
          header: "Munitions restantes (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWrestantes6mm",
        },
        {
          header: "Munitions usées (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWusees6mm",
        },
        {
          header: "Munitions détruites (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWdetruites6mm",
        },
        // {
        //   header: "Date de sortie (Cartouches à blancs 6mm TG3529AO)",
        //   key: "TG6768AWdateSortie6mm",
        // },
        // {
        //   header: "Date de retour (Cartouches à blancs 6mm TG3529AO)",
        //   key: "TG6768AWdateRetour6mm",
        // },
        {
          header: "Observations (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWobservations6mm",
        },

        {
          header: "Munitions reçues (Fusées détonnantes TG3529AO)",
          key: "TG3529AOrecuesDetonnants",
        },
        {
          header: "Munitions utilisées (Fusées détonnantes TG3529AO)",
          key: "TG3529AOutiliseesDetonnants",
        },
        {
          header: "Munitions restantes (Fusées détonnantes TG3529AO)",
          key: "TG3529AOrestantesDetonnants",
        },
        {
          header: "Munitions usées (Fusées détonnantes TG3529AO)",
          key: "TG3529AOuseesDetonnants",
        },
        {
          header: "Munitions détruites (Fusées détonnantes TG3529AO)",
          key: "TG3529AOdetruitesDetonnants",
        },
        // {
        //   header: "Date de sortie (Fusées détonnantes TG3529AO)",
        //   key: "TG3529AOdateSortieDetonnants",
        // },
        // {
        //   header: "Date de retour (Fusées détonnantes TG3529AO)",
        //   key: "TG3529AOdateRetourDetonnants",
        // },
        {
          header: "Observations (Fusées détonnantes TG3529AO)",
          key: "TG3529AOobservationsDetonnants",
        },

        {
          header: "Munitions reçues (Fusées détonnantes TG6768AW)",
          key: "TG6768AWrecuesDetonnants",
        },
        {
          header: "Munitions utilisées (Fusées détonnantes TG6768AW)",
          key: "TG6768AWutiliseesDetonnants",
        },
        {
          header: "Munitions restantes (Fusées détonnantes TG6768AW)",
          key: "TG6768AWrestantesDetonnants",
        },
        {
          header: "Munitions usées (Fusées détonnantes TG6768AW)",
          key: "TG6768AWuseesDetonnants",
        },
        {
          header: "Munitions détruites (Fusées détonnantes TG6768AW)",
          key: "TG6768AWdetruitesDetonnants",
        },
        // {
        //   header: "Date de sortie (Fusées détonnantes TG6768AW)",
        //   key: "TG6768AWdateSortieDetonnants",
        // },
        // {
        //   header: "Date de retour (Fusées détonnantes TG6768AW)",
        //   key: "TG6768AWdateRetourDetonnants",
        // },

        {
          header: "Munitions reçues (Fusées crépitantes TG3529AO)",
          key: "TG3529AOrecuesCrepitants",
        },
        {
          header: "Munitions utilisées (Fusées crépitantes TG3529AO)",
          key: "TG3529AOutiliseesCrepitants",
        },
        {
          header: "Munitions restantes (Fusées crépitantes TG3529AO)",
          key: "TG3529AOrestantesCrepitants",
        },
        {
          header: "Munitions usées (Fusées crépitantes TG3529AO)",
          key: "TG3529AOuseesCrepitants",
        },
        {
          header: "Munitions détruites (Fusées crépitantes TG3529AO)",
          key: "TG3529AOdetruitesCrepitants",
        },
        // {
        //   header: "Date de sortie (Fusées crépitantes TG3529AO)",
        //   key: "TG3529AOdateSortieCrepitants",
        // },
        // {
        //   header: "Date de retour (Fusées crépitantes TG3529AO)",
        //   key: "TG3529AOdateRetourCrepitants",
        // },
        {
          header: "Observations (Fusées crépitantes TG3529AO)",
          key: "TG3529AOobservationsCrepitants",
        },

        {
          header: "Munitions reçues (Fusées crépitantes TG6768AW)",
          key: "TG6768AWrecuesCrepitants",
        },
        {
          header: "Munitions utilisées (Fusées crépitantes TG6768AW)",
          key: "TG6768AWutiliseesCrepitants",
        },
        {
          header: "Munitions restantes (Fusées crépitantes TG6768AW)",
          key: "TG6768AWrestantesCrepitants",
        },
        {
          header: "Munitions usées (Fusées crépitantes TG6768AW)",
          key: "TG6768AWuseesCrepitants",
        },
        {
          header: "Munitions détruites (Fusées crépitantes TG6768AW)",
          key: "TG6768AWdetruitesCrepitants",
        },
        // {
        //   header: "Date de sortie (Fusées crépitantes TG6768AW)",
        //   key: "TG6768AWdateSortieCrepitants",
        // },
        // {
        //   header: "Date de retour (Fusées crépitantes TG6768AW)",
        //   key: "TG6768AWdateRetourCrepitants",
        // },
        {
          header: "Observations (Fusées crépitantes TG6768AW)",
          key: "TG6768AWobservationsCrepitants",
        },

        {
          header:
            "Munitions reçues (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOrecuesAutres",
        },
        {
          header:
            "Munitions utilisées (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOutiliseesAutres",
        },
        {
          header:
            "Munitions restantes (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOrestantesAutres",
        },
        {
          header:
            "Munitions usées (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOuseesAutres",
        },
        {
          header:
            "Munitions détruites (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOdetruitesAutres",
        },
        // {
        //   header: "Date de sortie (Autres munitions d'effarouchement TG3529AO)",
        //   key: "TG3529AOdateSortieAutres",
        // },
        // {
        //   header: "Date de retour (Autres munitions d'effarouchement TG3529AO)",
        //   key: "TG3529AOdateRetourAutres",
        // },
        {
          header: "Observations (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOobservationsAutres",
        },

        {
          header:
            "Munitions reçues (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWrecuesAutres",
        },
        {
          header:
            "Munitions utilisées (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWutiliseesAutres",
        },
        {
          header:
            "Munitions restantes (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWrestantesAutres",
        },
        {
          header:
            "Munitions usées (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWuseesAutres",
        },
        {
          header:
            "Munitions détruites (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWdetruitesAutres",
        },
        // {
        //   header: "Date de sortie (Autres munitions d'effarouchement TG6768AW)",
        //   key: "TG6768AWdateSortieAutres",
        // },
        // {
        //   header: "Date de retour (Autres munitions d'effarouchement TG6768AW)",
        //   key: "TG6768AWdateRetourAutres",
        // },
        {
          header: "Observations (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWobservationsAutres",
        },

        // { header: "Commentaires de l'administrateur", key: "commentaireAdmin" },
      ];
      this.loading = true;
      var m = new Date();
      var dateString =
        ("0" + m.getUTCDate()).slice(-2) + "-" +
        ("0" + (m.getUTCMonth() + 1)).slice(-2) + "-" +
        m.getUTCFullYear() + " " +
        ("0" + m.getUTCHours()).slice(-2) + ":" +
        ("0" + m.getUTCMinutes()).slice(-2);
      const snapshot = await firestore().collection("armesMunitions").where("idForm", "==", idForm).get();
      const documents = snapshot.docs.map((doc) => doc.data());
      const doc = new jsPDF();
      let pageHeight = doc.internal.pageSize.height;
      doc.addImage("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAC5CAMAAABa+IDIAAABIFBMVEX////3/PYAjzb8/vv1/fUCkDn5+/b39AD///34/PX3/PgAkTbXIxYAjjoAfL35+/j68wAAer3u9/ICjDsKlEAhisAAe7Y1pmEMf73M5+ux3MGy2OOGwNrh8ebO6djV7Nwem08Ae8OVyNs0lcYZmkvX6+rj8vGBx5274Mkpj8Sm0eFBrGt5w5Z9vNM8mcmDxSZXqM9Enca+3hlmvIkPljRwviZatn6d1LJKrXFtstKVzR7a6QiSz6pgqsYinjJCqy5Wsyut1hbV5wzepZ/UJh349DveHRQtdTHRNSjoycGgO0HeVUrZRDnbhnowZpdySWHs29TadGpRXoJdhTD1zQw1lJVutcjNU0LhixMAi16gzkzQ5kPbZVdEh7VlrGwAgYkp1n3kAAAbJklEQVR4nO1dC3vaOLNGluxa8tpeCwzmYjDBBBIIJSUl0NL0tvud7r273/Wc71z+/784M7IhkIQExzTZp08mbRJIYvRac3lnNBKFwp9IzMcewH7ENL8OIE84/lxifh1AzCccfyr5mnA89hj2IV8Rjscewn7kK4HxJE/yJE/yJE/yJE/ysEIpRT4IpBC+eezBZBNmuIQxQgwhqGBhs7ZY9Hq9xXmtGboUhRGDMEM89jjvFByoIVvN8+EsKtkaiG2BaDZIXJn2as2WpNQgjz3Ou4QWaL83rcSWpum2peuagqDDQ03XbcCklaLBZNF87HFuFcYEB4Wh/Wlc0nEeEIEGSKx0PgAGfIVn4Ae6XoqHLdMlhJE/m44ZhivC/qSk7j3CUOOOo6gym0565yiLxXAyG1SiuITQNDvqNaUQ7LFHfkVooT+pwG0HZdJ0+LC1ymRx3gd7gB+a6LzwAzyYRPsfzmLEog16rcce+KWAC2LCqFVQo2xdobCiSU1KsiWFxSelbC0GNuheadoSRIg/g+0zl4W1ip2qlK7H0bBZMF3h3vZHJiG0IM8HccnWp6Bht/7yAwmVi4qNRoE2bg96fWK6rkHusmJeIMI0W+cTgDKrPW6wJBy8Dq1FGC3Qfq3ipCWzKokMF7GmzUJwYe5jeTBGXKM11c/QvnVLj4eS3qFRN19ELCJLX8jHsxSDhr0S6hNqVWURmoKAZL0KkBmT1AZ2dE4fZUbACGgTtEpXISOuSUFzXE3IfsWeScofHgsTsmdBnAbr0EsTQt1ceiGYy3tx3CcPHx/N5gxUykIc02YBqG4+BaeCmK2JNpR55jW7wKvWYsVELDvqy3tdQn0SQPmXTBgCSz+qtAyY3QebF0P2EkJraVOZgy4xLqtdZqweEz6Nm8RlfB+D3EXkRFcRUI/OTXGvl6XJHxF52l3zukS4i2jhsofRL0OEAzRzYOizljDu/oNrAoyfwD8I7+aJL8nGjaCtwRCcOLvPdTMKCytakltM7hmLAQRRBJ7I4OgKEGbIwVCQBzATs1WBuQDriBdm9vCnhArelRgy6NzrXAECEMlkIr94lCeiGSGv0q24f+/gBYoz7zLGSNdvdyS7cvOJS86n0iDsi2IRIVBdjB5R6N7bJDmtB11CuGw4AIRcu45rLIZ30uecElaQ5up6JczBjAjz/SpEEBk4ztHhNUMTxKCLofyCZkJcCfaBVLcS3huG4NxsOEGVE3PueI7fvcnQqFvrZc4Idhcip4gDUtkctmgIcdhxfAAiPSfw/OqNjlaI7KnN7kIhnqOdw3zkeBHBjwOYEcEb5WDeDuri5sn9YukJF+Y52jnMR0sUchgIYSOv3K4T2fFGXc873ubDc9LQ7QMQzZLSK6uVi0EwXvectncg4MsBDcon8oGpu5ADHSuHpT7NRR8I7zgj35uTuRNIcwwR8cEoIoiAfHQI7kovWr170atLoTAT9bHTEb4zNvFB9yGBEEL7qqRrzfK+LB07R926U663nSpnPHDmD1kLYiKMVeUqknkDbtcvjzkDv1U+YkBDIJbIB0RCyETDqk/czOcUCTfrgVcnfOy0nRNOBKsG3onJH4C0J2I0S6o4vTALuXyMAVPQDrjgAMerC4NSeQrB/eFq8mSGKzdWRd6fKSbX4bLjjCG6wxcfklyTGnWwkgeqAhFinqvKj97K+4KMHTpenQMrPG2PkMCbnL+BuaHkIVwXc2Ws41LTgvKc2TQjx57DOIGw3h5Tlc8K5jte1RAPgIS5Q7UGVZG5X00UICcEHAJSqkYChJFqAA6ZPwAQEUZo6aXze1R2rwgzjxxwvgSclXNMVe5EuDjwyqdMumuWgv6ME67WuXO+5JqQBS4c2JU9kDhhBk6DGESAiVeX4yZ87pVHlK/NNyOcG9ygpnE1Ec4jMlLLUffP0S+Fccc55oKQuuN1l3EQkt5x2zmVZLUkQWX1eD7yfX/UqO6tiCrMBS7jWLN90GohHadOBBHHyBiXzxIhx453Kg21dGTQ6nwESbDn4H/v9JjzfZS5DOHChJxpdsvdg7a6IXhfmBAA4qyXjDk7dTxfokbx6giCZdvxx/P5HDIXJxhzvof83aAYQyxrKvdhdkbYVkBQtdaBEEbHngqRVdAyLzg9ltiIY1LZ8D3Quj2UhpjEoK6VaqKwB2VlzEMbEaLuON216wlQn7nndeonMBt+owrsizDwWwY3D8eBM95D/i5aMZKTaD8UlaHXAmMXwBXrmzeGkAPPCRyv3JCMq0U8tCX4xMbgIPIDcc/V8kFvP1SbFjreGNeuqz7EkY0fge86Djyn04X4IcjyA35V8iMwn9wvTQY6ZoZ7qs0Ic+z4EAjJ4ZEzv7JiCACAEyMQtj4hYP9dz5sX8ppoaIPz1Sb58vSVEAONQ8AAR86pca1rC+sSRxx4F1F9HfDB0FIYmE9uDtNTjUnNPS0dA1sMvLlJBJ0Hfte4MjbKDXDLp0gq0wkBSLIrJRCak1y9ahCHInS+FZmbZaUXZHLsBVIwo+4F9WvaQtB3OSdyNSFYBCuPGTl1OrmUm5JQLekM8wx+QwQ/LoPfYpyD3t8UHeTIc6rGckKIUW0HHuMHTlDNA0QYC1U7qeW4xoYYgnU77VEoOB0DSbmu9pBCBmUf5iN1W5yeeifCkJ7XyAOEUKw56FHLEHTF4QUBcnrPq1KD0IbjHcMFug4S+WvX4bTuYTkinRLGTckNVoA8LA9LMcIB5uoDTAw56gOkEhR5ncEoveeFOR/BXDDJT50AE45rvwBW5B+yZSQB9wvzwueOn8drGa0I212HUoZrIkEIce/ZLEYgbXc6cEvgzjeoedUbmiapB+WGuzQSmBSDSXmFZO70QuApCoKaBRo2+9j9Y2tRVMJeS8tWLXKluFKZTXqLWjNkQOwg6ca2rQxASMNz5oQfdpzOIb8yI9iyzTptoImJzwIFqB7MR50jxzksZCPzarle1npT7AdNmkZ11chka2m3H/bLaZZdKkWVWa9PCtj3mmkLnhyVPfC9B23v+MpKIeKgYEW4xKhwGPWRD5weKJg34ltWUrYIEefTyMYoiGvQSeexrl0VPWl9wO7kSq+ZMcww6XtBlXPfOdp0XAoHOC7wAy4C4d0Rknp/dBpApjW/On13vIpQ67ZqFnAdAfvKsA1ZTwQrp/DD5ElbTY6mxdNFP4RRCHRnd983iA4KSb3snECUX2FROMC6TeAv4FoEO0AWOa/ij+rjIKhjrrgzEFdUknuu+hSxjcm+lGIRP9nKYFRjbNIiBKDiaLYIC4BF3G0vnGN90a9ySHCrYMsbOAAIbXg+TTKU4OAwWYPjEjLHQ5ahSkxpRU+HVwQTPzu7ePvu5fNX718k8v7V8+fv3p6daar7IdU51TiOi3LDJji0O2cEJk4cgMZIYLvArJa/n8wHiFt1HCYg+21DzgiunyENA/54MOIZdJiDatlF/ewtjP/V+w/Pvt2Q1cPXH94DoLeQzIOd4JK1WrfW7HjWq7WkiX4VIg69cXaIwLgIc+KDDdeX1BEnRPF2Ig5hpuQp5rgwL1T5EQDP6WE3A3XkpHLx7tWLD6+fqUE/U/It/ls+wB8kgJ69/vDi+buSVVRWpSXtphr458l5iBRAufIbBeh5I2g7Y9/rSGM1IQkORZGP521vLK8oUqZN1pJ9n4w/+fRsm3yb/AZi+vD8Qk+1TFkWapkdTWoh8vGb6wZg4lUfmDykJwd8hUMoJELII6fjlEf59jIw8v3GaJMZWFOqbzd/lvz4wyswnCLuFAG70tIdIwDm48fPnyUMkeHdxkCbDg3cz9jz6iZwR0/is6lipTPS8TxcJc1VBSLi+/RGpwgSFfqAhg7/P4DOrezlEg1azYtX7y6Kto5gEh9gW//xl+8+/fzT7x9/CEHT4YZjLVclhoQeOE7DhHkJPCwGXyqWmpGOh04tBwqcEfH95fhevHr+7iLWzrSirhWT2KEVtRI4sufvX6/PSmJEz56BlqFyqc0XCsg3qXz3z18+fpZIahkGGqMLEQLScSFHMOQlkLTcwEG1gmOesyhHCMzI6xfgky4wcBeLSltQ99Gci8k3+HxRuwA4L9QErWvZ6/cv316gdoFXBiDffbOSv3zz6Z+///Lx4w8/fP48bkN8I1wAr4VUgy81S02KcQJkzLzWK0mznUTA+H+9e3tR0oqoJeBZbS3d3bJJUbCTHAK7fnHx9uX7Z6mirVyAUjO4xOWMrKEBcJ9+BI1imAhSDI2SKFNPZ8Q8Bsd7Ta9oIWPjE7hfsFbdOtOXNDFRlRTL6pNCZ6sNYJb29tXrb5+tsCwn6P3Lv25g+CXVMvj/q+N1mcux2BOUnTpfmxAs3vndaxGchotsKRAEROTsul1UYQ53ecGdR4eEBa4iEhTdVlvYEJAiXbaOevbyxYdEy5b2Ag/+to7ju88/L7/90StDFqjqV+bYccbm0kTgn4SMq06vzgih/WHGPZluBS1COVG7qCFDeff81av3S3n16uXLRPeQfFnIK1UJD7GAlr1OPHWCZRPIT+HHJaRfgfeyxCB4HfhtGkVwDyYFoznh7jUDobWemYn9EpgRte3u4q0y5TWXtKE4r188f3mhJWASDgzmbZesi+cfLknABpBf+Of0u9880KbURTERQCihS+HHDvrjaxSamIuFmSmxYqwCk/DqQ0pQVma8QrE0BPVzMOq3FxZqm9I31MaiFgPFea1+cQnk559AfnD57/Dl528+/eqNJHETi+BkBLCoOjuIKAMB0sKupR7MHGbcYML4v19/e2X4G7xk9cwyLgJ9fKuBSQGYNJ20ixBqXsLNWAH5iPHQEECWPv/3N79h4mSkUZwYoEsH1AAcgvGur9odb1CUwrSWzdhVZF8PDRsYtvKv9+809MapV1MuwLJKf12630+/y6Q0/cMncFlexzSMlJBw98CDGK+0hkvfcerGTd0DolBpZlug4RDZ12iu+va1kg/qA2TTWFbh4wUEQnRmlq1yLfTha3HkJ1Wq+gWe+KMNFpLURBWpxHIKAFEcyykfUHFTRwcxS2E2DikUkGXOARQFso63by8uzkpnmlY6u4AIiKkKOoLlvK2opdKyUtHG/BHj/zqQTwwN+3dwvYEzZ2QVxoUBbuvAVHswRp53soX4s9Cm2QpQMCM4QBjRxVl6Y4vFNN9VGa6luK11BsmjCupXFfDZC/RmSH91DUjjymcJ8VGKH8DSsSB9WbYCINiMAok86FV7zrd0pdBalLEjlPB/Q66kGIqlNkFjgpGkf6r6YCefIcxYSfB4B2nkJntUfAvmULPXZuTz59+/+fSD+O4PCHeu0qwlaQdGUoV8FvLeYG6SLVyR92aFbHVaiCNFZbaatiycaKs90apIhMWV9GeWKkiU0F0vg/rKnX148Qopyneffvvttx8//fTxZ2BZ3338H+CIZjoXCgfjc8/hVM4DJ2hsL/jQ2SQTDEysKklNMXVBaTVFWz5jW8nXZd1B0WHbOrt49+Lb687ub//616+4+F/2//jxxx9/+6PsgfYsC7uJjfCONzLr4K6COtvenyejWsZVZY7lIGUcy/GWosF0Mhn2UIaTybQSRVFcSs5BSCcNSQ2o2btX4NKuZJCv/+60veSf58H/U8mNNIFSxUR+6HjzcdkJRhJp/bZhNUthNhyoWmgXdowF3qHaQb/80YqzUdnq1xbD6SBW3gk/1KEIoGVYuNgIQ6//7gXjRmM+Pu10OqN5XeIaoVpcgy8cOMm8jd0ao4Pbm6hqcdaVDABiVybnrTCUgjRjGGdxs7OUmi4uURrgZmTYPJ/GtpUSR+0MeyR08GbPP1yqGQCBsMGwhn8osdxNeUqrktYZr+y0/bok12nJugwHWZdjKW8CkxBAhUCXwwpaem3jGuBgBAGCASQDdARIUrgY4EEP4J0xgmAWA7S/BPafMM7/9bwDhpwKojiMfRx4HvDdIIDPoHD4becYe5zcW/s0KsPsyxh0pUQGmaGPmtyZB4T93ixSFdSk6o35CnozLPE999pjtAsM4tVTr132sCLtgMV4TuCP5sfVa8nHVSFGaNdyVVSMHgKp3AUEBwlqNozSorby2Jjf23Z8EQeBf4hNAIxXAUHnoNrtdqv1+nG9Wu1K7Ai6ad1q8/qiFzfznEJARB9dUrw8xmTLeYouMQz8R83wfBbj2hCmJsi4UM3sctJsJgyg6EHDBBMHPXOBUhmu2nEo7tySTwpRJdemBi4MPC7DOl/CuLNmaRZkfzGplPSkXq+KW//pOL7kzOj6YNT3Wvd3m9rEzFPmcllhgsqijGS3Y1OJ4RosbPWHFTsJpMBmyk55XiBs7gTHt7umbWJOtFpGynhFDNpEWhLLFMcOQBjDZUIuXAJg0JtZOCUQtcFAOnQbJ7xdwqhE8radG2jAdo2S7OfY4lok6NmsUvo/UK4T3/GO76UeplGzpvf5ww0RPSwtVGBu7nFyqmG41JWgaL6HfZbB/XosBZnZ+U9NIk3FDVviHjgoeFwkAVwc+tgzegu5vU1YqFV2T0W2jZNIXFK0JjTPSbbMleOg3blfSzopzLTerpa+3QAY7WEoiVp5egGB5srqQfd+LSxGX4+bO1r6LR7JJWEJ61WLewxhJdilSFTv0j3+WMys2a5/aNLtmmMWpshpK19+i/lNAregX9J3DiK34GDUDVUF8fxL7dS8VZjLZna083liW4EAn6fEnWCqHuc7wuWeIty+bdVurHTdJNtxqAxI7RSzhg979koiQkZ6JUO3w204TC6nSP/ixzjKj050vZYliNz8rMIB2tVX/U6TR9AteOVBBgJ/Mw6a4EDONFXrH7fspoSknFFDsEuWDswRve7qocpIkoemUIs8Qnllsv2ihMiBDbw3X/P0CkeBFVwZ42pOxLZOckJq+frITSyRiMuH9HLzEVPMjapP5tU25kth5tDSBzd0cGaBcYmjIODWnKvy4tbkndLq/PT0zYG8LHjKRqNxfEmu8OHhckjMrTdW0t0aI4yabmvAa3IQ+HUcKDDHai97Tdx0/5jojrAe4rXLyy0IgtfLba98mX1gul5NW69Bm+ae57STAkT9Zm/IXNKKNGuRK59amvnaVftYvTqrhDelqmo9IBiPR47XoCkOMcdKycHqEgpIuhUeTOkkCLCWEgR+UL9ZXw0mZppWydVJfg0H7mcfopXY05ssj1W9clBlTFZHKRDVQwp3fLQOBLvlkt/nBMt1MIsNKbdtOyJgILbWz7NN7DoOFFFRRZ7eDRUPfgw3vw72wXi4HCoMPPBx4T81k2rQ9qobfypHkKFsyXzBKtyFbWnDwv07nZQ7uSHUiyaecWYVz8k1rRVdsJDgFOu6ac8hJyeOMx+3gwOWMBszUa11c7gNCCSktZKlz4xMu7U3xrx0i9d+i7kLVUGMW9fO/wMbcbwymK5/nC68cu577W6j7I1l6rIVEGNXIIK1SroWtViWLGhj0ObW1AQMFc+p0ez42nEihHVPA8xlnaXXItW24+Pg/cPEwIWyEeXyIBAatwIx1BY1y9LOM2WUG8O+reZjuHKAnEsd8LIhzOC8ejzvgL8dpR3sY8c5OpkHbaeeNmMkqpXatXkNyPq9oYLiKoDVo9caOW6FsdYJelvJBwZPkm3UWnSl3552wdDBE80dryMpcIKCBAhg3WXPG5sE6ZqpZkQNm6UWeAkExsDWVjoNPCnD1iau2L2HfPMc9LsqV4z04zO0k0roCuMy3vLGUfWQSQBSHokT32+YeDqQDwKmI+nI96tMea3D7uGh5PA8to/KUdlpQNh2674/NpdzgrssMG2wBlkiSGrZKxR3mBZ3aS1pjI2aVFyeNsAbXrkzHp/CTT8ozNvOnGLrUihl6DvtgwJ2M+Due8c/6hx15hSs6dBIZwTP1Tsue53L1yDuOR4NHoUZpyP1UDsVRA1G3Jpq0LAQyUqx+QGMrVyGTwfE/AcAkUeOdyzBcuZe+6jgAw0BY2+3PWQxYwDiITNPgRDj2Gl3VvGC0IWq2gCF2HVG1gOGoqG7uDpwwiW1/KHVxKqll/HufHQEN7vLOD8ej+vdN2/mXSwRdsdv5vIfb8ZV3v3H+I2SA/5mPMZNCuwEfhP7OqrjNydJQQCX8zCv1qMMBy2tB4wtMfAmEeYiaSTQe8RNtQss3VRzikd68oLJXbggHsMI6scpGrf6Lpl1ynHXDsE1PhNXSrBnKDVTSszWQHmT5u4BfSPwZcABM94vJd0Ds2XHN6RTHASXFAl+hk8cYwUYADOwMs9w1w8XwhXUJQI7GbH1F9d2edoAkU4AmIdu2eDfM+jV+tjVg11vgTBqsVXEhcK4KYlr5Du75lKICCe4AceuhDv7q6s8JNOKgWBmP9KS/r9h7jORVkJprYJNFvZs94PhrvGpTJV2oIEiHKRNAlH/5p0V2UVOS7p+putDufOpJYmLylOUZkLOLNUwZBWH4R1L/XeIwHMZhazFOrZOxYss05H7TRQharmLOD1lPVrIPPUBARyG1gZ4LUgIa3TXA9X2gQO4CjjaZpS8lwXE+QXNo2Bmv1JSB7Zbk9Dd9VzZfcBIRYhJ0o+GhLgm8VBoChR59783wNpcIpsDtSFAt0rndOd3itkjDsyqa5Wz9ERpu7Jomdn6cglzhYnvFZH2sk1b5s7n9O0TBlYkXLkoYdcZtgpq8ayf7dq00J9GqFHYWBj11QLMTrdir9ORCDjiGZJI1U8Ho+lJiW0ZVLCtRUmh3giGEBkuolULXtzLcDbF/mEgy3PN2izdhKFUbNCrAeGjxtadjxTPaGrVegN1KoaCEk9adPf1sN1hZJg5FxtiZH+mmk5VL51ul6LKpBYi77kBBVw1PJ9UIrXikrzrSnHYBLvfuX6169jMlex44QLOS3NWSrbDJptegTDFg+F5SyZCsB6H/5u14aBk28lvpSdrT7KxnN1hpEXfLDpIhWs2JxU1Pn3ZWKslO3grs0TwXYbUluulHuIvxINFaGZa0tsNxxJGVgJDDODoFN80ybb0dNO42iC3HHOqdEnjI8ZQdA/qbZNckmnxfUcY9F4w1sQAw8cQjdqjLZuFN7eYqV29ACmeNK+XLPch952NDWG0IGuTQaQ06wYg6kk9jma9PgVfYH6BAzP3MB0FVcuBJFC2+ufDQWxfWsxyfmw7mg5rzZCYkFMaO4a/LLKX6dgUInmz1lNvJRbhG4wNpsNFLWSFfRw3tl32DgOFCeMyBU1e5Iu/L9ISx94uKArAhJO9LrjDAlch1RsRfekF7v1PxyPJVwLj6Y3en+RJnuRJ9iL7T80fR75EkeEx5AsUfR5FnnD8ueQrgfF14bjH3/0/lk5u9D4FEIEAAAAASUVORK5CYII=", 'JPEG', 20, 0, 25, 25)
      doc.setFontSize(16);
      doc.setFont("helvetica");
      doc.setTextColor(255, 0, 0);
      doc.text("Armes et munitions (Code: " + idForm + ")", 105, 15, null, null, "center");
      doc.setTextColor(0, 2, 3);
      let i = 35;
      Columns.forEach((element) => {
        doc.text(element["header"], 10, i, { align: "left", });
        i = i + 10;
        doc.setTextColor(255, 0, 0);
        doc.text(documents[0][element["key"]], 10, i, { align: "left", });
        doc.setTextColor(0, 2, 3);
        if (i >= pageHeight) {
          doc.addPage();
          i = 15
        } else {
          i = i + 10;
        }
      });
      doc.setTextColor(51, 10, 199);
      doc.text("Ce document a été généré par le système GES-UPRA au " + dateString, 105, pageHeight - 5, { align: "center", });
      doc.autoPrint({ variant: 'non-conform' });
      doc.output('dataurlnewwindow');
      this.loading = false;
    },


    ...mapActions({
      loadgestionSecurite: "gestionSecurite/loadgestionSecurite",
    }),
    openLink(link) {
      window.open(link, "_blank");
    },
    ...mapActions({
      addgestionSecurite: "gestionSecurite/addgestionSecurite",
      updategestionSecurite: "gestionSecurite/updategestionSecurite",
      removegestionSecurite: "gestionSecurite/removegestionSecurite",
    }),
    getgestionSecuriteById: function (id) {
      let gestionSecurite = this.gestionSecurite.filter((c) => c.id == id)[0];
      console.log(gestionSecurite.status);
      if (gestionSecurite === undefined) {
        console.log("undefined qarşim");
        return { nom: "Unknown" };
      }
      return gestionSecurite;
    },
    exportPDF() {
      this.loading2 = true;
      let exportColumns = [{
        title: "ID",
        dataKey: "idForm",
      },
      {
        title: "Agent",
        dataKey: "userName",
      },
      {
        title: "Intitulé",
        dataKey: "intitulePassation",
      },
      { title: "Adresse email", dataKey: "userEmail" },
      { title: "Date et heure", dataKey: "dateEnvoi" },
      {
        title: "Vacation",
        dataKey: "vacation",
      },
      {
        title: "Agent entrant",
        dataKey: "nomEtPrenomAgentEntrant",
      },
      {
        title: "Agent sortant",
        dataKey: "nomEtPrenomAgentSortant",
      },
      // { title: "Commentaires de l'administrateur", dataKey: "commentaireAdmin" },
      { title: "Statut", dataKey: "status" },
      ];
      import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(() => {
          const doc = new jsPDF.default('l', 'pt', "a4");
          doc.setFontSize(16);
          doc.setFont("helvetica");
          doc.text("Liste des passations d'armes et munitions", 30, 30, { align: "justify", });
          doc.autoTable(exportColumns, this.gestionSecurite);
          doc.save("Liste des passations d'armes et munitions.pdf");
          this.loading2 = false;
        })
      });
    },
    //To upload
    async uploadTaskImages() {
      this.snack = true;
      this.snackColor = "danger";
      this.snackText = this.$refs.uploader.files.length + " images prises en compte";
      let vm = this;
      vm.defaultItem.imagesJoined = [];
      for (let i = 0; i < this.$refs.uploader.files.length; i++) {
        const newImage = this.$refs.uploader.files[i];
        if (newImage != null && newImage.name) {
          let ref = storage()
            .ref()
            .child("images/" + newImage.name);
          await ref.put(newImage).then((snapshot) => {
            if (snapshot.state === "success") {
              snapshot.ref.getDownloadURL().then(function (downloadURL) {
                vm.defaultItem.imagesJoined.push(downloadURL);
              });
            }
          });
        }
      }
    },

    async uploadTaskDocuments() {
      this.snack = true;
      this.snackColor = "danger";
      this.snackText = this.$refs.uploader1.files.length + " documents prises en compte";
      let vm = this;
      vm.defaultItem.documentsJoined = [];
      for (let i = 0; i < this.$refs.uploader1.files.length; i++) {
        const newDocument = this.$refs.uploader1.files[i];
        if (newDocument != null && newDocument.name) {
          let ref = storage()
            .ref()
            .child("documents/" + newDocument.name);
          await ref.put(newDocument).then((snapshot) => {
            if (snapshot.state === "success") {
              snapshot.ref.getDownloadURL().then(function (downloadURL) {
                vm.defaultItem.documentsJoined.push(downloadURL);
              });
            }
          });
        }
      }
    },
    //-------------------------------------------------------------end upload

    async exportToExcel() {

      this.loading1 = true;
      let workbook = new Excel.Workbook();
      let worksheet = workbook.addWorksheet("Passation des armes et munitions");
      worksheet.columns = [
        {
          header: "ID",
          key: "idForm",
        },
        {
          header: "Nom et prénoms de l'agent",
          key: "userName",
        },
        {
          header: "Intitulé",
          key: "intitulePassation",
        },
        { header: "Adresse email de l'agent", key: "userEmail" },
        { header: "Date et heure d'envoi", key: "dateEnvoi" },

        {
          header: "Vacation",
          key: "vacation",
        },
        {
          header: "Agent entrant",
          key: "nomEtPrenomAgentEntrant",
        },
        {
          header: "Agent sortant",
          key: "nomEtPrenomAgentSortant",
        },
        { header: "Etat (REVOLVER 9mm RJ131910645)", key: "RJ131910645etat" },
        {
          header: "Anomalies (REVOLVER 9mm RJ131910645)",
          key: "RJ131910645anomalies",
        },
        {
          header: "Date de sortie (REVOLVER 9mm RJ131910645)",
          key: "RJ131910645dateSortie",
        },
        {
          header: "Date de retour (REVOLVER 9mm RJ131910645)",
          key: "RJ131910645dateRetour",
        },
        {
          header: "Observations (REVOLVER 9mm RJ131910645)",
          key: "RJ131910645observations",
        },

        { header: "Etat (REVOLVER 9mm RJ120205375)", key: "RJ120205375etat" },
        {
          header: "Anomalies (REVOLVER 9mm RJ120205375)",
          key: "RJ120205375anomalies",
        },
        {
          header: "Date de sortie (REVOLVER 9mm RJ120205375)",
          key: "RJ120205375dateSortie",
        },
        {
          header: "Date de retour (REVOLVER 9mm RJ120205375)",
          key: "RJ120205375dateRetour",
        },
        {
          header: "Observations (REVOLVER 9mm RJ120205375)",
          key: "RJ120205375observations",
        },

        { header: "Etat (REVOLVER 6mm RL130410466)", key: "RJ120205375etat" },
        {
          header: "Anomalies (REVOLVER 6mm RL130410466)",
          key: "RL130410466anomalies",
        },
        {
          header: "Date de sortie (REVOLVER 6mm RL130410466)",
          key: "RL130410466dateSortie",
        },
        {
          header: "Date de retour (REVOLVER 6mm RL130410466)",
          key: "RL130410466dateRetour",
        },
        {
          header: "Observations (REVOLVER 6mm RL130410466)",
          key: "RL130410466observations",
        },

        {
          header: "Munitions reçues (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOrecues",
        },
        {
          header: "Munitions utilisées (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOutilisees",
        },
        {
          header: "Munitions restantes (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOrestantes",
        },
        {
          header: "Munitions usées (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOusees",
        },
        {
          header: "Munitions détruites (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOdetruites",
        },
        // {
        //   header: "Date de sortie (Cartouches à blancs 9mm TG3529AO)",
        //   key: "TG3529AOdateSortie",
        // },
        // {
        //   header: "Date de retour (Cartouches à blancs 9mm TG3529AO)",
        //   key: "TG3529AOdateRetour",
        // },
        {
          header: "Observations (Cartouches à blancs 9mm TG3529AO)",
          key: "TG3529AOobservations",
        },

        {
          header: "Munitions reçues (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWrecues",
        },
        {
          header: "Munitions utilisées (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWutilisees",
        },
        {
          header: "Munitions restantes (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWrestantes",
        },
        {
          header: "Munitions usées (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWusees",
        },
        {
          header: "Munitions détruites (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWdetruites",
        },
        // {
        //   header: "Date de sortie (Cartouches à blancs 9mm TG6768AW)",
        //   key: "TG6768AWdateSortie",
        // },
        // {
        //   header: "Date de retour (Cartouches à blancs 9mm TG6768AW)",
        //   key: "TG6768AWdateRetour",
        // },
        {
          header: "Observations (Cartouches à blancs 9mm TG6768AW)",
          key: "TG6768AWobservations",
        },

        {
          header: "Munitions reçues (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOrecues6mm",
        },
        {
          header: "Munitions utilisées (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOutilisees6mm",
        },
        {
          header: "Munitions restantes (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOrestantes6mm",
        },
        {
          header: "Munitions usées (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOusees6mm",
        },
        {
          header: "Munitions détruites (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOdetruites6mm",
        },
        // {
        //   header: "Date de sortie (Cartouches à blancs 6mm TG3529AO)",
        //   key: "TG3529AOdateSortie6mm",
        // },
        // {
        //   header: "Date de retour (Cartouches à blancs 6mm TG3529AO)",
        //   key: "TG3529AOdateRetour6mm",
        // },
        {
          header: "Observations (Cartouches à blancs 6mm TG3529AO)",
          key: "TG3529AOobservations6mm",
        },

        {
          header: "Munitions reçues (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWrecues6mm",
        },
        {
          header: "Munitions utilisées (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWutilisees6mm",
        },
        {
          header: "Munitions restantes (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWrestantes6mm",
        },
        {
          header: "Munitions usées (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWusees6mm",
        },
        {
          header: "Munitions détruites (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWdetruites6mm",
        },
        // {
        //   header: "Date de sortie (Cartouches à blancs 6mm TG3529AO)",
        //   key: "TG6768AWdateSortie6mm",
        // },
        // {
        //   header: "Date de retour (Cartouches à blancs 6mm TG3529AO)",
        //   key: "TG6768AWdateRetour6mm",
        // },
        {
          header: "Observations (Cartouches à blancs 6mm TG3529AO)",
          key: "TG6768AWobservations6mm",
        },

        {
          header: "Munitions reçues (Fusées détonnantes TG3529AO)",
          key: "TG3529AOrecuesDetonnants",
        },
        {
          header: "Munitions utilisées (Fusées détonnantes TG3529AO)",
          key: "TG3529AOutiliseesDetonnants",
        },
        {
          header: "Munitions restantes (Fusées détonnantes TG3529AO)",
          key: "TG3529AOrestantesDetonnants",
        },
        {
          header: "Munitions usées (Fusées détonnantes TG3529AO)",
          key: "TG3529AOuseesDetonnants",
        },
        {
          header: "Munitions détruites (Fusées détonnantes TG3529AO)",
          key: "TG3529AOdetruitesDetonnants",
        },
        // {
        //   header: "Date de sortie (Fusées détonnantes TG3529AO)",
        //   key: "TG3529AOdateSortieDetonnants",
        // },
        // {
        //   header: "Date de retour (Fusées détonnantes TG3529AO)",
        //   key: "TG3529AOdateRetourDetonnants",
        // },
        {
          header: "Observations (Fusées détonnantes TG3529AO)",
          key: "TG3529AOobservationsDetonnants",
        },

        {
          header: "Munitions reçues (Fusées détonnantes TG6768AW)",
          key: "TG6768AWrecuesDetonnants",
        },
        {
          header: "Munitions utilisées (Fusées détonnantes TG6768AW)",
          key: "TG6768AWutiliseesDetonnants",
        },
        {
          header: "Munitions restantes (Fusées détonnantes TG6768AW)",
          key: "TG6768AWrestantesDetonnants",
        },
        {
          header: "Munitions usées (Fusées détonnantes TG6768AW)",
          key: "TG6768AWuseesDetonnants",
        },
        {
          header: "Munitions détruites (Fusées détonnantes TG6768AW)",
          key: "TG6768AWdetruitesDetonnants",
        },
        // {
        //   header: "Date de sortie (Fusées détonnantes TG6768AW)",
        //   key: "TG6768AWdateSortieDetonnants",
        // },
        // {
        //   header: "Date de retour (Fusées détonnantes TG6768AW)",
        //   key: "TG6768AWdateRetourDetonnants",
        // },

        {
          header: "Munitions reçues (Fusées crépitantes TG3529AO)",
          key: "TG3529AOrecuesCrepitants",
        },
        {
          header: "Munitions utilisées (Fusées crépitantes TG3529AO)",
          key: "TG3529AOutiliseesCrepitants",
        },
        {
          header: "Munitions restantes (Fusées crépitantes TG3529AO)",
          key: "TG3529AOrestantesCrepitants",
        },
        {
          header: "Munitions usées (Fusées crépitantes TG3529AO)",
          key: "TG3529AOuseesCrepitants",
        },
        {
          header: "Munitions détruites (Fusées crépitantes TG3529AO)",
          key: "TG3529AOdetruitesCrepitants",
        },
        // {
        //   header: "Date de sortie (Fusées crépitantes TG3529AO)",
        //   key: "TG3529AOdateSortieCrepitants",
        // },
        // {
        //   header: "Date de retour (Fusées crépitantes TG3529AO)",
        //   key: "TG3529AOdateRetourCrepitants",
        // },
        {
          header: "Observations (Fusées crépitantes TG3529AO)",
          key: "TG3529AOobservationsCrepitants",
        },

        {
          header: "Munitions reçues (Fusées crépitantes TG6768AW)",
          key: "TG6768AWrecuesCrepitants",
        },
        {
          header: "Munitions utilisées (Fusées crépitantes TG6768AW)",
          key: "TG6768AWutiliseesCrepitants",
        },
        {
          header: "Munitions restantes (Fusées crépitantes TG6768AW)",
          key: "TG6768AWrestantesCrepitants",
        },
        {
          header: "Munitions usées (Fusées crépitantes TG6768AW)",
          key: "TG6768AWuseesCrepitants",
        },
        {
          header: "Munitions détruites (Fusées crépitantes TG6768AW)",
          key: "TG6768AWdetruitesCrepitants",
        },
        // {
        //   header: "Date de sortie (Fusées crépitantes TG6768AW)",
        //   key: "TG6768AWdateSortieCrepitants",
        // },
        // {
        //   header: "Date de retour (Fusées crépitantes TG6768AW)",
        //   key: "TG6768AWdateRetourCrepitants",
        // },
        {
          header: "Observations (Fusées crépitantes TG6768AW)",
          key: "TG6768AWobservationsCrepitants",
        },

        {
          header:
            "Munitions reçues (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOrecuesAutres",
        },
        {
          header:
            "Munitions utilisées (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOutiliseesAutres",
        },
        {
          header:
            "Munitions restantes (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOrestantesAutres",
        },
        {
          header:
            "Munitions usées (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOuseesAutres",
        },
        {
          header:
            "Munitions détruites (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOdetruitesAutres",
        },
        // {
        //   header: "Date de sortie (Autres munitions d'effarouchement TG3529AO)",
        //   key: "TG3529AOdateSortieAutres",
        // },
        // {
        //   header: "Date de retour (Autres munitions d'effarouchement TG3529AO)",
        //   key: "TG3529AOdateRetourAutres",
        // },
        {
          header: "Observations (Autres munitions d'effarouchement TG3529AO)",
          key: "TG3529AOobservationsAutres",
        },

        {
          header:
            "Munitions reçues (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWrecuesAutres",
        },
        {
          header:
            "Munitions utilisées (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWutiliseesAutres",
        },
        {
          header:
            "Munitions restantes (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWrestantesAutres",
        },
        {
          header:
            "Munitions usées (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWuseesAutres",
        },
        {
          header:
            "Munitions détruites (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWdetruitesAutres",
        },
        // {
        //   header: "Date de sortie (Autres munitions d'effarouchement TG6768AW)",
        //   key: "TG6768AWdateSortieAutres",
        // },
        // {
        //   header: "Date de retour (Autres munitions d'effarouchement TG6768AW)",
        //   key: "TG6768AWdateRetourAutres",
        // },
        {
          header: "Observations (Autres munitions d'effarouchement TG6768AW)",
          key: "TG6768AWobservationsAutres",
        },

        // { header: "Commentaires de l'administrateur", key: "commentaireAdmin" },
        { header: "Statut", key: "status" },
      ];
      worksheet.columns.forEach(function (column) {
        var maxLength = 0;
        column["eachCell"]({ includeEmpty: true }, function (cell) {
          var columnLength = cell.value ? cell.value.toString().length : 10;
          if (columnLength > maxLength) {
            maxLength = columnLength;
          }
        });
        column.width = maxLength < 10 ? 10 : maxLength;
      });
      worksheet.getRow(1).font = { bold: true, color: { argb: "0047AB" } };
      const snapshot = await firestore().collection("armesMunitions").get();
      snapshot.forEach((doc) => {
        let e = doc.data();
        worksheet.addRow({
          ...e,
        });
      });
      workbook.xlsx.writeBuffer().then((data) => {
        const blob = new Blob([data], {
          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        });
        fs.saveAs(blob, `gestionSecurite.xlsx`);
      });
      this.loading1 = false;
    },
    async initialize() {
      this.loading = true;
      try {
        await this.loadgestionSecurite();
      } catch (e) {
        console.error(e);
      }
      this.loading = false;
    },

    editItem(item) {
      this.editedIndex = this.gestionSecurite.indexOf(item);
      this.editedItem = Object.assign({}, item);
      this.dialog = true;
    },

    viewItem(item) {
      this.editedIndex = this.gestionSecurite.indexOf(item);
      this.editedItem = Object.assign({}, item);
      this.editedItem["RJ131910645dateSortie"] = moment(this.editedItem["RJ131910645dateSortie"], 'DD-MM-YYYY HH:mm').format('YYYY-MM-DD');
      this.editedItem["RJ131910645dateRetour"] = moment(this.editedItem["RJ131910645dateRetour"], 'DD-MM-YYYY HH:mm').format('YYYY-MM-DD');
      this.editedItem["dateRJ120205375dateSortieIncident"] = moment(this.editedItem["dateRJ120205375dateSortieIncident"], 'DD-MM-YYYY HH:mm').format('YYYY-MM-DD');
      this.editedItem["RJ120205375dateRetour"] = moment(this.editedItem["RJ120205375dateRetour"], 'DD-MM-YYYY HH:mm').format('YYYY-MM-DD');
      this.editedItem["RL130410466dateSortie"] = moment(this.editedItem["RL130410466dateSortie"], 'DD-MM-YYYY HH:mm').format('YYYY-MM-DD');
      this.editedItem["RL130410466dateRetour"] = moment(this.editedItem["RL130410466dateRetour"], 'DD-MM-YYYY HH:mm').format('YYYY-MM-DD');

      this.dialogView = true;
    },

    close() {
      this.dialog = false;
      this.$nextTick(() => {
        this.editedItem = Object.assign({}, this.defaultItem);
        this.editedIndex = -1;
      });
    },
    addItem() {
      this.editedIndex = -1;
      this.defaultItem = Object.assign({}, this.defaultItemInit);
      this.dialogAdd = true;
    },
    closeAdd() {
      this.dialogAdd = false;
      this.$nextTick(() => {
        this.editedItem = Object.assign({}, this.defaultItem);
        this.editedIndex = -1;
      });
    },
    closeView() {
      this.dialogView = false;
      this.$nextTick(() => {
        this.editedItem = Object.assign({}, this.defaultItem);
        this.editedIndex = -1;
      });
    },

    async save() {
      if (!this.$refs.dialogForm.validate()) return;
      this.loading = true;
      if (this.editedIndex <= -1) {
        this.snack = true;
        this.snackColor = "blue";
        this.snackText = "Action en cours...";
        await this.uploadTaskImages();
        await this.uploadTaskDocuments();
      }

      if (this.editedIndex > -1) {
        this.loading = true;
        try {
          await this.updategestionSecurite({
            index: this.editedIndex,
            order: this.editedItem,
          });
          this.loading = false;
          this.dialogView = false;
          this.dialogAdd = false;
          this.close();
          this.snack = true;
          this.snackColor = "success";
          this.snackText = "Le statut du formulaire a été mise à jour";
        } catch (e) {
          this.loading = false;
          this.close();

          this.snack = true;
          this.snackColor = "error";
          this.snackText =
            "Le statut du formulaire n'a pas pu être mise à jour";
          console.error(e);
        }
      } else {
        this.loading = true;
        try {
          await this.addgestionSecurite(this.defaultItem);
          this.loading = false;
          this.close();
          this.dialogAdd = false;
          this.snack = true
          this.snackColor = 'success'
          this.snackText = 'Formulaire ajouté avec succès.'
        } catch (e) {
          this.loading = false;
          this.close();
          this.snack = true
          this.snackColor = 'error'
          this.snackText = 'Le formulaire n\'a pas été ajouté.'
          console.error(e);
        }
      }
    },
  },
  filters: {
    truncate: function (text, length, suffix) {
      if (text.length > length) {
        return text.substring(0, length) + suffix;
      } else {
        return text;
      }
    },
  },
};
</script>